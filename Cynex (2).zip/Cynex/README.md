# Cynex — On-Device AI Assistant for Android

Cynex is a futuristic, ChatGPT-style Android assistant that runs **fully on-device**
using a local GGUF model (default target: **DeepSeek R1 Distill 1.5B**). It can chat,
control your phone via Accessibility services, speak responses, and float as an
overlay bubble.

> **Important — this is a complete project skeleton.** It compiles and runs as a
> chat UI in *stub mode* out of the box. To enable real on-device GGUF inference,
> follow the **llama.cpp setup** section below before building.

---

## 1. Requirements

- **Android Studio** Hedgehog or newer (Iguana / Koala recommended)
- **Android SDK 34**, build-tools 34.x
- **Android NDK 26.x** and **CMake 3.22.1** (install from SDK Manager → SDK Tools)
- A physical Android device (8.0+) for testing — emulators don't expose
  AccessibilityService gestures or overlay reliably
- Git (for cloning llama.cpp)

## 2. Open the project

1. Unzip `Cynex.zip`.
2. In Android Studio: **File → Open** → select the `Cynex` folder.
3. Let Gradle sync. The first sync downloads Gradle 8.7 and dependencies.

## 3. Enable on-device inference (llama.cpp)

The native bridge `app/src/main/cpp/llama_jni.cpp` already implements the full
JNI glue. You only need to provide llama.cpp's source:

```bash
cd app/src/main/cpp
git clone https://github.com/ggerganov/llama.cpp.git
```

CMake will detect it automatically and build `cynex-llama` against `llama`. If
the folder is missing, the project still builds — the engine just runs in
**stub mode** and shows a friendly placeholder response.

> The llama.cpp ggml-quants targets benefit from `arm64-v8a`. Building for
> `armeabi-v7a` works but is much slower; remove it from `abiFilters` in
> `app/build.gradle.kts` if you only target 64-bit devices.

## 4. Get the model

1. Download a GGUF build of DeepSeek R1 Distill 1.5B (Q4_K_M is a good balance):
   <https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF>
2. Copy the `.gguf` file to your phone (Downloads folder is fine).
3. Open Cynex → **Settings → Add / Manage Local Models → Add GGUF** and pick the file.
4. Tap the model in the list to set it as active. Cynex will load it.

## 5. Grant permissions on first launch

The Permission Setup screen walks the user through:

- Microphone, notifications, storage
- Display over other apps (overlay bubble)
- Accessibility Service (phone control)

You can re-open these any time from **Settings → Permissions**.

## 6. Project layout

```
app/src/main/
├── AndroidManifest.xml
├── cpp/                    # llama.cpp JNI bridge & CMake
├── java/com/cynex/
│   ├── MainActivity.kt
│   ├── CynexApplication.kt
│   ├── core/               # constants, utils, security, di, managers
│   ├── ai/                 # engine, prompts, parser, memory, tools, models
│   ├── accessibility/      # service + gesture/scroll/tap/text controllers
│   ├── automation/         # routines, scheduler, triggers, executor
│   ├── voice/              # STT, TTS, wake word
│   ├── overlay/            # floating bubble service
│   ├── services/           # foreground, notification, clipboard, smart actions
│   ├── data/               # Room DB, repositories, datastore
│   └── ui/                 # Compose theme, navigation, screens, components
└── res/                    # themes, strings, accessibility config, drawables
```

## 7. Customising

- **Default chat template** — `ai/engine/PromptFormatter.kt` uses DeepSeek's
  `<|User|>` / `<|Assistant|>` tags. Adjust for other GGUF model families.
- **System prompt** — `ai/prompts/SystemPrompt.kt`.
- **Action JSON schema** — Cynex extracts `{"actions":[{"type":"OPEN_APP", ...}]}`
  from model output. Extend `Action.Type` and `AutomationExecutor` to add new
  device capabilities.
- **Wake word** — `core/constants/AppConstants.kt`. The default detector uses
  string matching; integrate Porcupine for production-grade always-on KWS.

## 8. Known limitations

- Stub mode replies until llama.cpp is cloned.
- Always-on background mic listening is heavy on battery; off by default.
- AccessibilityService is restricted on some OEM ROMs (MIUI, ColorOS) and may
  need special "auto-start" allowances per device.
- This project does not ship a release-signing config — generate your own keystore
  before publishing to Play.

## 9. License

Your code, your call. llama.cpp is MIT-licensed; respect the license of any
GGUF model weights you download (DeepSeek R1 weights are MIT for the base model).

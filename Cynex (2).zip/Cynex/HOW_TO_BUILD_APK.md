# How to get the Cynex APK

## Option 1 — GitHub Actions (no installs, ~10 minutes) — RECOMMENDED

1. Create a free account at <https://github.com> if you don't have one.
2. Create a new empty repository named `cynex`.
3. Unzip the project, open a terminal in the `Cynex` folder, and follow GitHub's
   "push an existing repository" instructions shown on your new repo's page.
4. Open the repo on github.com → **Actions** tab → wait for **Build Cynex APK** (~10 min).
5. Click the finished run → scroll to **Artifacts** → download **cynex-debug-apk**
   → unzip → you have `app-debug.apk`.
6. Copy the APK to your phone and tap **Install**.
   (Allow "Install unknown apps" if prompted.)

The workflow at `.github/workflows/build-apk.yml` downloads llama.cpp automatically,
so the resulting APK has real on-device GGUF inference built in.

---

## Option 2 — Android Studio on your computer

1. Install Android Studio: <https://developer.android.com/studio>
2. **File → Open** → select the unzipped `Cynex` folder. Let Gradle sync.
3. SDK Manager → SDK Tools → install **NDK 26.x** and **CMake 3.22.1**.
4. (For real AI) place llama.cpp at `app/src/main/cpp/llama.cpp`:
   download <https://github.com/ggerganov/llama.cpp> as a ZIP, extract it there.
5. **File → Sync Project with Gradle Files**.
6. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
7. APK: `app/build/outputs/apk/debug/app-debug.apk`.

---

## After installing on your phone

1. Open Cynex → follow the permission wizard (mic, overlay, accessibility).
2. Settings → **Add / Manage Local Models → Add GGUF** → pick your `.gguf` file.
   - Recommended: DeepSeek R1 Distill 1.5B Q4_K_M from HuggingFace
3. Tap the model to activate it.
4. Go to **Settings → Voice** and enable the **wake word** — then just say
   **"Hey Cynex"** from anywhere to activate it hands-free.
5. For the best voice, install Google TTS and download the Enhanced voice
   for your language (Settings → Voice → Open TTS Settings).

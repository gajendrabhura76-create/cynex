#!/bin/bash
# ╔══════════════════════════════════════════════════════════╗
# ║   Cynex — One-command GitHub upload + APK auto-build    ║
# ║   Run this script from INSIDE the Cynex folder          ║
# ╚══════════════════════════════════════════════════════════╝

set -e
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║   Cynex APK Builder — Mac / Linux    ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"
echo ""

# ── Step 1: Check git ────────────────────────────────────────
if ! command -v git &> /dev/null; then
  echo -e "${RED}✗ git is not installed.${NC}"
  echo "  Mac:   brew install git   OR   xcode-select --install"
  echo "  Linux: sudo apt install git"
  exit 1
fi
echo -e "${GREEN}✓ git found${NC}"

# ── Step 2: Install GitHub CLI if missing ───────────────────
if ! command -v gh &> /dev/null; then
  echo ""
  echo -e "${YELLOW}⚠ GitHub CLI (gh) is not installed. Installing now...${NC}"
  if [[ "$OSTYPE" == "darwin"* ]]; then
    if command -v brew &> /dev/null; then
      brew install gh
    else
      echo -e "${RED}Homebrew not found. Install it from https://brew.sh then re-run this script.${NC}"
      exit 1
    fi
  else
    # Linux
    curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | sudo dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
    echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" | sudo tee /etc/apt/sources.list.d/github-cli.list > /dev/null
    sudo apt update && sudo apt install gh -y
  fi
fi
echo -e "${GREEN}✓ GitHub CLI ready${NC}"

# ── Step 3: Log in to GitHub ─────────────────────────────────
echo ""
echo -e "${CYAN}Step 1/4 — Log in to GitHub${NC}"
echo "A browser window will open. Sign in and click Authorize."
echo ""
gh auth login --web --git-protocol https

# ── Step 4: Init git ─────────────────────────────────────────
echo ""
echo -e "${CYAN}Step 2/4 — Setting up local repository${NC}"
if [ ! -d ".git" ]; then
  git init
  git branch -M main
fi
git add -A
git commit -m "Cynex v2 — Futuristic AI assistant with Siri orb and wake word" 2>/dev/null || \
  git commit --allow-empty -m "Initial commit"

# ── Step 5: Create GitHub repo + push ───────────────────────
echo ""
echo -e "${CYAN}Step 3/4 — Creating private GitHub repository and uploading${NC}"
REPO_NAME="cynex-ai-assistant"
gh repo create "$REPO_NAME" \
  --private \
  --description "Cynex — Futuristic on-device AI assistant for Android" \
  --source=. \
  --remote=origin \
  --push 2>/dev/null || {
    echo -e "${YELLOW}Repository may already exist. Pushing to existing repo...${NC}"
    git push origin main --force 2>/dev/null || git push origin master --force 2>/dev/null
  }

# ── Step 6: Show result ──────────────────────────────────────
echo ""
echo -e "${CYAN}Step 4/4 — APK build started on GitHub Actions!${NC}"
echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════════╗${NC}"
echo -e "${GREEN}║  ✓ Code uploaded!  APK is building on GitHub now.        ║${NC}"
echo -e "${GREEN}║                                                           ║${NC}"
echo -e "${GREEN}║  What to do next:                                         ║${NC}"
echo -e "${GREEN}║  1. Wait ~10 minutes                                      ║${NC}"
echo -e "${GREEN}║  2. Open: https://github.com/$(gh api user -q .login)/$REPO_NAME/actions  ║${NC}"
echo -e "${GREEN}║  3. Click the finished run                                ║${NC}"
echo -e "${GREEN}║  4. Download 'cynex-debug-apk'                            ║${NC}"
echo -e "${GREEN}║  5. Unzip → send to phone → install!                      ║${NC}"
echo -e "${GREEN}╚══════════════════════════════════════════════════════════╝${NC}"
echo ""

# Open browser to Actions page
GITHUB_USER=$(gh api user -q .login)
ACTIONS_URL="https://github.com/$GITHUB_USER/$REPO_NAME/actions"
echo -e "Opening Actions page: ${CYAN}$ACTIONS_URL${NC}"
if [[ "$OSTYPE" == "darwin"* ]]; then
  open "$ACTIONS_URL"
else
  xdg-open "$ACTIONS_URL" 2>/dev/null || echo "Visit $ACTIONS_URL in your browser"
fi

@echo off
:: ╔══════════════════════════════════════════════════════════╗
:: ║   Cynex — One-command GitHub upload + APK auto-build    ║
:: ║   Double-click this file from inside the Cynex folder   ║
:: ╚══════════════════════════════════════════════════════════╝

title Cynex APK Builder

echo.
echo  ============================================
echo   Cynex APK Builder for Windows
echo  ============================================
echo.

:: ── Check git ──────────────────────────────────────────────
where git >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] git is not installed.
    echo.
    echo  Install it from: https://git-scm.com/download/win
    echo  Then re-run this script.
    pause
    exit /b 1
)
echo  [OK] git found

:: ── Check / install GitHub CLI ─────────────────────────────
where gh >nul 2>&1
if errorlevel 1 (
    echo.
    echo  GitHub CLI (gh) not found. Installing via winget...
    winget install --id GitHub.cli --silent --accept-package-agreements --accept-source-agreements
    if errorlevel 1 (
        echo.
        echo  winget failed. Download gh manually from:
        echo  https://cli.github.com
        echo  Install it, then re-run this script.
        pause
        exit /b 1
    )
    :: Refresh PATH for this session
    for /f "tokens=*" %%i in ('where gh 2^>nul') do set GH_PATH=%%i
    if "%GH_PATH%"=="" (
        echo  Please close and reopen this window, then run setup-windows.bat again.
        pause
        exit /b 1
    )
)
echo  [OK] GitHub CLI ready

:: ── Log in to GitHub ───────────────────────────────────────
echo.
echo  Step 1/4 - Log in to GitHub
echo  A browser window will open. Sign in and click Authorize.
echo.
gh auth login --web --git-protocol https

:: ── Init git ───────────────────────────────────────────────
echo.
echo  Step 2/4 - Setting up local repository
if not exist ".git" (
    git init
    git branch -M main
)
git add -A
git commit -m "Cynex v2 - Futuristic AI assistant with Siri orb and wake word" 2>nul || git commit --allow-empty -m "Initial commit"

:: ── Create repo + push ─────────────────────────────────────
echo.
echo  Step 3/4 - Creating private GitHub repository and uploading
set REPO_NAME=cynex-ai-assistant
gh repo create %REPO_NAME% --private --description "Cynex on-device AI assistant" --source=. --remote=origin --push
if errorlevel 1 (
    echo  Repository may already exist. Pushing to existing repo...
    git push origin main --force 2>nul || git push origin master --force 2>nul
)

:: ── Show result ────────────────────────────────────────────
echo.
echo  Step 4/4 - APK build started on GitHub Actions!
echo.
echo  ============================================================
echo   SUCCESS! Your code is uploaded and the APK is building.
echo  ============================================================
echo.
echo   What to do next:
echo   1. Wait about 10 minutes
echo   2. A browser will open to your GitHub Actions page
echo   3. Click the finished run (green checkmark)
echo   4. Scroll down to Artifacts
echo   5. Click "cynex-debug-apk" to download
echo   6. Unzip it, send app-debug.apk to your phone, install!
echo.

:: Open Actions page in browser
for /f "tokens=*" %%u in ('gh api user -q .login') do set GITHUB_USER=%%u
set ACTIONS_URL=https://github.com/%GITHUB_USER%/%REPO_NAME%/actions
echo  Opening: %ACTIONS_URL%
start "" "%ACTIONS_URL%"

echo.
pause

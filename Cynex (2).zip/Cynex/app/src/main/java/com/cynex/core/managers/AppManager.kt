package com.cynex.core.managers

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppManager @Inject constructor(@ApplicationContext private val context: Context) {

    data class AppInfo(val label: String, val packageName: String)

    fun installedApps(): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(intent, 0).map { ri: ResolveInfo ->
            AppInfo(
                label = ri.loadLabel(pm).toString(),
                packageName = ri.activityInfo.packageName
            )
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }

    fun launch(packageName: String): Boolean = try {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
        context.startActivity(intent)
        true
    } catch (_: PackageManager.NameNotFoundException) { false }

    fun resolveByName(query: String): String? {
        val q = query.lowercase()
        return installedApps()
            .firstOrNull { it.label.lowercase().contains(q) }
            ?.packageName
    }
}

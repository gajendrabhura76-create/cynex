package com.cynex.ai.memory

import com.cynex.ai.models.ChatMessage
import com.cynex.core.utils.TimeUtils
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ConversationMemory @Inject constructor() {
    private val messages = mutableListOf<ChatMessage>()
    private val maxMessages = 60

    @Synchronized
    fun appendUser(content: String) {
        messages.add(ChatMessage(UUID.randomUUID().toString(), ChatMessage.Role.USER, content, TimeUtils.now()))
        trim()
    }

    @Synchronized
    fun appendAssistant(content: String) {
        messages.add(ChatMessage(UUID.randomUUID().toString(), ChatMessage.Role.ASSISTANT, content, TimeUtils.now()))
        trim()
    }

    @Synchronized
    fun snapshot(): List<ChatMessage> = messages.toList()

    @Synchronized
    fun clear() = messages.clear()

    private fun trim() {
        if (messages.size > maxMessages) {
            val drop = messages.size - maxMessages
            repeat(drop) { messages.removeAt(0) }
        }
    }
}

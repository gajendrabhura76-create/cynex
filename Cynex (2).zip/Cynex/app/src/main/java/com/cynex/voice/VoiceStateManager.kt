package com.cynex.voice

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VoiceStateManager @Inject constructor() {
    enum class State { IDLE, LISTENING, PROCESSING, SPEAKING }
    private val _state = MutableStateFlow(State.IDLE)
    val state: StateFlow<State> = _state
    fun set(s: State) { _state.value = s }
}

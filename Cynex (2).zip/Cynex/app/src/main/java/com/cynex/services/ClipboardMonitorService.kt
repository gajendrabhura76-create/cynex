package com.cynex.services

import android.app.Service
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.IBinder
import com.cynex.core.utils.Logger
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ClipboardMonitorService : Service() {
    private val cm by lazy { getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager }
    private val listener = ClipboardManager.OnPrimaryClipChangedListener {
        val text = cm.primaryClip?.getItemAt(0)?.text?.toString().orEmpty()
        if (text.isNotBlank()) Logger.d("[clipboard] $text")
    }
    override fun onCreate() { super.onCreate(); cm.addPrimaryClipChangedListener(listener) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { cm.removePrimaryClipChangedListener(listener); super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}

package com.cynex.accessibility

import android.accessibilityservice.AccessibilityService
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AccessibilityActions @Inject constructor() {
    fun back(): Boolean = CynexAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK) ?: false
    fun home(): Boolean = CynexAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME) ?: false
    fun recents(): Boolean = CynexAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS) ?: false
    fun notifications(): Boolean = CynexAccessibilityService.instance?.performGlobalAction(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS) ?: false
}

package com.cynex.overlay

import android.content.Context
import android.widget.FrameLayout
import android.widget.TextView

class MiniAssistantView(context: Context) : FrameLayout(context) {
    private val text = TextView(context).apply { text = "•"; textSize = 22f }
    init { addView(text) }
}

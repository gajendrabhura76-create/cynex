package com.cynex.ai.parser

import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class IntentParser @Inject constructor() {
    fun classify(userText: String): Action.Type {
        val t = userText.lowercase()
        return when {
            t.startsWith("open ") -> Action.Type.OPEN_APP
            t.contains("scroll") -> Action.Type.SCROLL
            t.contains("tap ") || t.contains("click ") -> Action.Type.TAP
            t.contains("type ") || t.contains("write ") -> Action.Type.TYPE_TEXT
            t.contains("setting") -> Action.Type.OPEN_SETTINGS
            t.contains("bluetooth") -> Action.Type.TOGGLE_BLUETOOTH
            t.contains("wifi") || t.contains("wi-fi") -> Action.Type.TOGGLE_WIFI
            t.contains("notification") -> Action.Type.READ_NOTIFICATIONS
            t.contains("reply") -> Action.Type.REPLY_MESSAGE
            t == "back" -> Action.Type.BACK
            t == "home" -> Action.Type.HOME
            else -> Action.Type.NONE
        }
    }
}

package com.cynex.core.managers

import com.cynex.accessibility.AutomationExecutor
import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ActionManager @Inject constructor(
    private val executor: AutomationExecutor
) {
    suspend fun run(actions: List<Action>) = executor.runBatch(actions)
}

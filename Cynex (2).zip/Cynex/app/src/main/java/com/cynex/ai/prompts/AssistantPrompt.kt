package com.cynex.ai.prompts

object AssistantPrompt {
    const val greeting = "Hi, I'm Cynex. I run on your device and can chat or control your phone. Try \"open YouTube\" or just ask me anything."
}

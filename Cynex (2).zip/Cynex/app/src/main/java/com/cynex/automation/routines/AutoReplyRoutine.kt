package com.cynex.automation.routines

import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutoReplyRoutine @Inject constructor() {
    fun build(message: String): List<Action> = listOf(
        Action(Action.Type.REPLY_MESSAGE, text = message)
    )
}

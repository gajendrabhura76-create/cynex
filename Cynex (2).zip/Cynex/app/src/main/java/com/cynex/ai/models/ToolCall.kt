package com.cynex.ai.models

import kotlinx.serialization.Serializable

@Serializable
data class ToolCall(
    val name: String,
    val arguments: Map<String, String> = emptyMap()
)

package com.cynex.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.cynex.data.local.datastore.UserPreferences
import com.cynex.ui.navigation.Routes
import com.cynex.ui.theme.CynexAccent
import com.cynex.ui.theme.CynexAccentAlt
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SplashViewModel @Inject constructor(
    private val prefs: UserPreferences
) : ViewModel() {
    suspend fun firstRoute(): String =
        if (prefs.onboardingDone.first()) Routes.CHAT else Routes.ONBOARDING
}

@Composable
fun SplashScreen(navController: NavHostController, vm: SplashViewModel = hiltViewModel()) {
    var visible by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        visible = true
        delay(900)
        val next = vm.firstRoute()
        navController.navigate(next) { popUpTo(Routes.SPLASH) { inclusive = true } }
    }

    val pulse = rememberInfiniteTransition(label = "pulse")
    val scale by pulse.animateFloat(
        initialValue = 0.95f, targetValue = 1.05f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "pulseScale"
    )

    Box(Modifier.fillMaxSize().background(CynexBg), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .scale(scale)
                    .background(
                        Brush.radialGradient(listOf(CynexAccent, CynexAccentAlt))
                    )
            )
            Spacer(Modifier.height(24.dp))
            Text("Cynex", color = CynexText, style = MaterialTheme.typography.displaySmall)
            Spacer(Modifier.height(6.dp))
            Text("Your on-device AI assistant", color = CynexTextDim,
                style = MaterialTheme.typography.bodyMedium, modifier = Modifier.alpha(if (visible) 1f else 0f))
        }
    }
}

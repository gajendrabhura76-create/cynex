package com.cynex.core.di

import com.cynex.ai.engine.LlamaEngine
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AiModule {
    @Provides @Singleton
    fun provideLlamaEngine(): LlamaEngine = LlamaEngine()
}

package com.cynex.ai.memory

import com.cynex.ai.engine.Tokenizer
import com.cynex.ai.models.ChatMessage
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ContextManager @Inject constructor(private val tokenizer: Tokenizer) {
    fun fitToWindow(messages: List<ChatMessage>, maxTokens: Int): List<ChatMessage> {
        val out = ArrayDeque<ChatMessage>()
        var total = 0
        for (msg in messages.reversed()) {
            val t = tokenizer.approxCount(msg.content)
            if (total + t > maxTokens) break
            out.addFirst(msg); total += t
        }
        return out.toList()
    }
}

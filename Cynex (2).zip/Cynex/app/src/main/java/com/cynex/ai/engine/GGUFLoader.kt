package com.cynex.ai.engine

import android.content.Context
import android.net.Uri
import com.cynex.ai.models.ModelConfig
import com.cynex.core.constants.AppConstants
import com.cynex.core.utils.FileUtils
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GGUFLoader @Inject constructor() {
    fun importFromUri(context: Context, uri: Uri, displayName: String): ModelConfig? {
        val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        val file = FileUtils.copyUriToInternal(context, uri, safeName) ?: return null
        return ModelConfig(
            name = safeName.removeSuffix(".gguf"),
            path = file.absolutePath,
            contextSize = AppConstants.DEFAULT_CONTEXT_SIZE,
            temperature = AppConstants.DEFAULT_TEMPERATURE,
            maxTokens = AppConstants.DEFAULT_MAX_TOKENS
        )
    }

    fun listLocalModels(context: Context): List<ModelConfig> =
        FileUtils.modelsDir(context).listFiles().orEmpty()
            .filter { it.extension.equals("gguf", ignoreCase = true) }
            .map { ModelConfig(name = it.nameWithoutExtension, path = it.absolutePath) }
}

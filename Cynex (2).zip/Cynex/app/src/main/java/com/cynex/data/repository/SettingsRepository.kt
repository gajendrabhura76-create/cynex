package com.cynex.data.repository

import com.cynex.data.local.database.SettingsDao
import com.cynex.data.local.entities.SettingsEntity
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsRepository @Inject constructor(private val dao: SettingsDao) {
    suspend fun set(key: String, value: String) = dao.upsert(SettingsEntity(key, value))
    suspend fun get(key: String): String? = dao.get(key)
    suspend fun remove(key: String) = dao.remove(key)
}

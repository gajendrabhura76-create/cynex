package com.cynex.data.local.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.cynex.data.local.entities.ChatEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChatDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(message: ChatEntity)

    @Query("SELECT * FROM chats WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun observeBySession(sessionId: String): Flow<List<ChatEntity>>

    @Query("SELECT DISTINCT sessionId FROM chats ORDER BY timestamp DESC")
    fun sessions(): Flow<List<String>>

    @Query("DELETE FROM chats WHERE sessionId = :sessionId")
    suspend fun deleteSession(sessionId: String)

    @Query("DELETE FROM chats")
    suspend fun deleteAll()
}

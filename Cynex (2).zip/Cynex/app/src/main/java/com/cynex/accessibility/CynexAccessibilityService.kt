package com.cynex.accessibility

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import com.cynex.core.utils.Logger

class CynexAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Logger.i("CynexAccessibilityService connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Hook for notification reading & UI inspection
        event ?: return
        when (event.eventType) {
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                NotificationReader.handle(event)
            }
            else -> {}
        }
    }

    override fun onInterrupt() { Logger.w("Accessibility interrupted") }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    companion object {
        @Volatile var instance: CynexAccessibilityService? = null
            private set
    }
}

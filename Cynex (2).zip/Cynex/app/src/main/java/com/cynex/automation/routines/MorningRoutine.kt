package com.cynex.automation.routines

import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class MorningRoutine @Inject constructor() {
    fun build(): List<Action> = listOf(
        Action(Action.Type.TOGGLE_WIFI),
        Action(Action.Type.OPEN_APP, target = "Calendar")
    )
}

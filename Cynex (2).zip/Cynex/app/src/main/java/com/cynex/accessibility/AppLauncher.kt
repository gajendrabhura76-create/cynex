package com.cynex.accessibility

import com.cynex.core.managers.AppManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppLauncher @Inject constructor(private val appManager: AppManager) {
    fun launchByName(name: String): Boolean {
        val pkg = appManager.resolveByName(name) ?: return false
        return appManager.launch(pkg)
    }
}

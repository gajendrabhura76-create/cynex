package com.cynex.ai.models

import kotlinx.serialization.Serializable

@Serializable
data class ChatMessage(
    val id: String,
    val role: Role,
    val content: String,
    val timestamp: Long,
    val streaming: Boolean = false
) {
    enum class Role { USER, ASSISTANT, SYSTEM }
}

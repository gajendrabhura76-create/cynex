package com.cynex.automation.triggers
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationTrigger @Inject constructor() {
    fun matches(pkg: String, watchPkg: String) = pkg == watchPkg
}

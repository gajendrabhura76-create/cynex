package com.cynex.accessibility

import android.view.accessibility.AccessibilityEvent
import com.cynex.core.utils.Logger
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

object NotificationReader {
    private val _events = MutableSharedFlow<NotificationEvent>(extraBufferCapacity = 32)
    val events: SharedFlow<NotificationEvent> = _events

    data class NotificationEvent(val packageName: String, val text: String)

    fun handle(event: AccessibilityEvent) {
        val pkg = event.packageName?.toString() ?: return
        val text = event.text?.joinToString(" ").orEmpty()
        if (text.isBlank()) return
        Logger.d("[notif] $pkg: $text")
        _events.tryEmit(NotificationEvent(pkg, text))
    }
}

package com.cynex.data.repository

import com.cynex.ai.models.ChatMessage
import com.cynex.data.local.database.ChatDao
import com.cynex.data.local.entities.ChatEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ChatRepository @Inject constructor(private val dao: ChatDao) {

    fun observe(sessionId: String): Flow<List<ChatMessage>> =
        dao.observeBySession(sessionId).map { list -> list.map { it.toDomain() } }

    suspend fun save(sessionId: String, message: ChatMessage) =
        dao.insert(
            ChatEntity(
                id = message.id,
                sessionId = sessionId,
                role = message.role.name,
                content = message.content,
                timestamp = message.timestamp
            )
        )

    suspend fun clearSession(id: String) = dao.deleteSession(id)
    suspend fun clearAll() = dao.deleteAll()

    fun sessions(): Flow<List<String>> = dao.sessions()

    private fun ChatEntity.toDomain() = ChatMessage(
        id = id,
        role = ChatMessage.Role.valueOf(role),
        content = content,
        timestamp = timestamp
    )
}

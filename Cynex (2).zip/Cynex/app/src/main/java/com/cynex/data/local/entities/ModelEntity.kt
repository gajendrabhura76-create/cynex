package com.cynex.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey val path: String,
    val name: String,
    val contextSize: Int,
    val temperature: Float,
    val maxTokens: Int,
    val isActive: Boolean = false
)

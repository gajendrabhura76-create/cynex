package com.cynex.voice

import com.cynex.ai.parser.IntentParser
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VoiceCommandProcessor @Inject constructor(
    private val intentParser: IntentParser,
    private val wakeWord: WakeWordDetector
) {
    data class Result(val payload: String, val isCommand: Boolean)

    fun process(spoken: String): Result {
        val text = if (wakeWord.isWakeWord(spoken)) wakeWord.strip(spoken) else spoken
        val isCommand = intentParser.classify(text) != com.cynex.ai.models.Action.Type.NONE
        return Result(text, isCommand)
    }
}

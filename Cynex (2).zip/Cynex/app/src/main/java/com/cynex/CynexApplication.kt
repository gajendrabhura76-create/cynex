package com.cynex

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CynexApplication : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(
                    "cynex_assistant",
                    "Cynex Assistant",
                    NotificationManager.IMPORTANCE_LOW
                ).apply { description = "Persistent Cynex assistant" }
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    "cynex_overlay",
                    "Cynex Overlay",
                    NotificationManager.IMPORTANCE_MIN
                ).apply { description = "Floating bubble overlay" }
            )
            nm.createNotificationChannel(
                NotificationChannel(
                    "cynex_actions",
                    "Cynex Actions",
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply { description = "Automation results & alerts" }
            )
        }
    }
}

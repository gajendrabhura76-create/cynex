package com.cynex.ai.memory

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SessionManager @Inject constructor() {
    private val _id = MutableStateFlow(UUID.randomUUID().toString())
    val id: StateFlow<String> = _id
    fun startNew() { _id.value = UUID.randomUUID().toString() }
}

package com.cynex.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.*

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

@Composable
fun SiriOrb(
    state: OrbState,
    amplitude: Float = 0f,
    modifier: Modifier = Modifier,
    size: Dp = 180.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "orb")

    val breathScale by infiniteTransition.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(2200, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "breath"
    )
    val rotationA by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(8000, easing = LinearEasing)),
        label = "rotA"
    )
    val rotationB by infiniteTransition.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
        label = "rotB"
    )
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "glow"
    )
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "wave"
    )

    val stateScale by animateFloatAsState(
        targetValue = when (state) {
            OrbState.IDLE -> 1f
            OrbState.LISTENING -> 1.12f + amplitude * 0.18f
            OrbState.THINKING -> 1.05f
            OrbState.SPEAKING -> 1.08f + amplitude * 0.12f
        },
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "stateScale"
    )

    val color1 by animateColorAsState(
        targetValue = when (state) {
            OrbState.IDLE -> Color(0xFF6C63FF)
            OrbState.LISTENING -> Color(0xFF00E5FF)
            OrbState.THINKING -> Color(0xFFFF6B35)
            OrbState.SPEAKING -> Color(0xFF00FF88)
        },
        animationSpec = tween(600), label = "c1"
    )
    val color2 by animateColorAsState(
        targetValue = when (state) {
            OrbState.IDLE -> Color(0xFF9B59FF)
            OrbState.LISTENING -> Color(0xFF0099FF)
            OrbState.THINKING -> Color(0xFFFFB700)
            OrbState.SPEAKING -> Color(0xFF00CFFF)
        },
        animationSpec = tween(600), label = "c2"
    )
    val color3 by animateColorAsState(
        targetValue = when (state) {
            OrbState.IDLE -> Color(0xFF3B82F6)
            OrbState.LISTENING -> Color(0xFFB347FF)
            OrbState.THINKING -> Color(0xFFFF4081)
            OrbState.SPEAKING -> Color(0xFF7B2FF7)
        },
        animationSpec = tween(600), label = "c3"
    )

    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.size(size)) {
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val r = (this.size.minDimension / 2f) * stateScale * breathScale

            drawGlowRings(cx, cy, r, color1, color2, glowAlpha)
            rotate(rotationA, Offset(cx, cy)) {
                drawFluidBlob(cx, cy, r * 0.82f, color1, color2, wavePhase, amplitude)
            }
            rotate(rotationB, Offset(cx, cy)) {
                drawFluidBlob(cx, cy, r * 0.65f, color2, color3, wavePhase + 1f, amplitude * 0.7f)
            }
            drawCoreGlow(cx, cy, r * 0.45f, color1, color3)
            if (state == OrbState.LISTENING || state == OrbState.SPEAKING) {
                drawWaveRing(cx, cy, r * 1.15f, color1, wavePhase, amplitude)
            }
        }
    }
}

private fun DrawScope.drawGlowRings(cx: Float, cy: Float, r: Float, c1: Color, c2: Color, alpha: Float) {
    for (i in 4 downTo 1) {
        drawCircle(
            brush = Brush.radialGradient(
                listOf(c1.copy(alpha = alpha * 0.06f * i), Color.Transparent),
                center = Offset(cx, cy), radius = r * (1f + i * 0.22f)
            ),
            radius = r * (1f + i * 0.22f), center = Offset(cx, cy)
        )
    }
}

private fun DrawScope.drawFluidBlob(cx: Float, cy: Float, r: Float, c1: Color, c2: Color, phase: Float, amp: Float) {
    val pts = 120
    val path = Path()
    for (i in 0..pts) {
        val angle = (i.toFloat() / pts) * 2f * PI.toFloat()
        val noise = sin(angle * 3f + phase) * 0.06f +
                sin(angle * 5f + phase * 1.3f) * 0.04f +
                amp * sin(angle * 7f + phase * 0.8f) * 0.08f
        val rr = r * (1f + noise)
        val x = cx + rr * cos(angle)
        val y = cy + rr * sin(angle)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, brush = Brush.radialGradient(
        listOf(c1.copy(alpha = 0.85f), c2.copy(alpha = 0.6f), Color.Transparent),
        center = Offset(cx, cy), radius = r * 1.1f
    ))
}

private fun DrawScope.drawCoreGlow(cx: Float, cy: Float, r: Float, c1: Color, c2: Color) {
    drawCircle(
        brush = Brush.radialGradient(
            listOf(Color.White.copy(alpha = 0.9f), c1.copy(alpha = 0.7f), c2.copy(alpha = 0.3f), Color.Transparent),
            center = Offset(cx - r * 0.2f, cy - r * 0.2f), radius = r
        ),
        radius = r, center = Offset(cx, cy)
    )
}

private fun DrawScope.drawWaveRing(cx: Float, cy: Float, r: Float, color: Color, phase: Float, amp: Float) {
    val pts = 80
    val path = Path()
    for (i in 0..pts) {
        val angle = (i.toFloat() / pts) * 2f * PI.toFloat()
        val wave = sin(angle * 8f + phase) * (8f + amp * 18f)
        val rr = r + wave
        val x = cx + rr * cos(angle)
        val y = cy + rr * sin(angle)
        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
    }
    path.close()
    drawPath(path, color = color.copy(alpha = 0.35f + amp * 0.3f), style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f))
}

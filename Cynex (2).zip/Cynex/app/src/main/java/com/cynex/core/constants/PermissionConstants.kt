package com.cynex.core.constants

object PermissionConstants {
    const val REQ_NOTIFICATIONS = 1001
    const val REQ_AUDIO = 1002
    const val REQ_STORAGE = 1003
    const val REQ_BLUETOOTH = 1004
    const val REQ_OVERLAY = 1010
    const val REQ_ACCESSIBILITY = 1011
    const val REQ_NOTIF_LISTENER = 1012
}

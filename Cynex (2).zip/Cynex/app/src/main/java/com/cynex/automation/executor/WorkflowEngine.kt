package com.cynex.automation.executor

import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WorkflowEngine @Inject constructor(private val taskExecutor: TaskExecutor) {
    suspend fun execute(workflow: List<Action>) = taskExecutor.runSequence(workflow)
}

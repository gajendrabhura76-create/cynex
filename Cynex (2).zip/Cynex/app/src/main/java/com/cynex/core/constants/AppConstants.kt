package com.cynex.core.constants

object AppConstants {
    const val APP_NAME = "Cynex"
    const val DEFAULT_MODEL_NAME = "DeepSeek R1 Distill 1.5B"
    const val DEFAULT_CONTEXT_SIZE = 2048
    const val DEFAULT_TEMPERATURE = 0.7f
    const val DEFAULT_TOP_P = 0.9f
    const val DEFAULT_MAX_TOKENS = 512
    const val WAKE_WORD = "hey cynex"
    const val DB_NAME = "cynex_db"
    const val SECURE_PREFS = "cynex_secure"
}

package com.cynex.ai.tools

import com.cynex.core.managers.AppManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppTool @Inject constructor(private val appManager: AppManager) {
    fun openByName(name: String): Boolean {
        val pkg = appManager.resolveByName(name) ?: return false
        return appManager.launch(pkg)
    }
}

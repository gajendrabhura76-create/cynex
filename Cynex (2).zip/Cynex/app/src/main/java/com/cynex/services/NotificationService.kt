package com.cynex.services

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import com.cynex.core.utils.Logger
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow

class NotificationService : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        sbn ?: return
        val pkg = sbn.packageName ?: return
        val title = sbn.notification.extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = sbn.notification.extras.getCharSequence("android.text")?.toString().orEmpty()
        Logger.d("[notif-listener] $pkg | $title | $text")
        events.tryEmit(Event(pkg, title, text, System.currentTimeMillis()))
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {}

    data class Event(val pkg: String, val title: String, val text: String, val time: Long)

    companion object {
        private val _events = MutableSharedFlow<Event>(extraBufferCapacity = 64)
        val events: SharedFlow<Event> = _events
    }
}

package com.cynex.ui.screens

import android.Manifest
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.cynex.ui.components.GlassCard
import com.cynex.ui.components.GradientButton
import com.cynex.ui.navigation.Routes
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim

@Composable
fun PermissionSetupScreen(navController: NavHostController) {
    val context = LocalContext.current
    val perms = remember {
        buildList {
            add(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.READ_MEDIA_AUDIO)
            else add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }.toTypedArray()
    }
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {}

    Column(
        Modifier.fillMaxSize().background(CynexBg).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(40.dp))
        Text("Permissions", color = CynexText, style = MaterialTheme.typography.displaySmall)
        Spacer(Modifier.height(8.dp))
        Text("Cynex needs a few permissions to assist you fully.",
            color = CynexTextDim, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))

        GlassCard(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column {
                Text("Microphone, Notifications, Storage",
                    color = CynexText, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("For voice input, alerts, and loading GGUF models from your device.",
                    color = CynexTextDim, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                GradientButton("Grant", onClick = { launcher.launch(perms) })
            }
        }

        GlassCard(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column {
                Text("Display Over Other Apps", color = CynexText, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("For the floating assistant bubble.", color = CynexTextDim, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                GradientButton("Open Settings", onClick = {
                    context.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            android.net.Uri.parse("package:${context.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                })
            }
        }

        GlassCard(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
            Column {
                Text("Accessibility Service", color = CynexText, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(6.dp))
                Text("Lets Cynex tap, scroll and type for you.", color = CynexTextDim, style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                GradientButton("Open Accessibility", onClick = {
                    context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                })
            }
        }

        Spacer(Modifier.weight(1f))
        GradientButton("Continue", onClick = {
            navController.navigate(Routes.CHAT) { popUpTo(Routes.PERMISSIONS) { inclusive = true } }
        }, modifier = Modifier.padding(bottom = 24.dp))
    }
}


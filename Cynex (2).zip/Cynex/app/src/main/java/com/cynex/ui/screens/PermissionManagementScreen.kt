package com.cynex.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.cynex.ui.components.GlassCard
import com.cynex.ui.components.GradientButton
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim

@Composable
fun PermissionManagementScreen(navController: NavHostController) {
    val context = LocalContext.current
    Scaffold(
        containerColor = CynexBg,
        topBar = {
            TopAppBar(
                title = { Text("Permissions", color = CynexText) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CynexBg)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("App Permissions", color = CynexText, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("Open system settings to review and change permissions.",
                        color = CynexTextDim, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    GradientButton("Open App Info") {
                        context.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                android.net.Uri.parse("package:${context.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("Accessibility", color = CynexText, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text("Enable Cynex Accessibility Service to allow phone control.",
                        color = CynexTextDim, style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(10.dp))
                    GradientButton("Open Accessibility") {
                        context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        }
    }
}

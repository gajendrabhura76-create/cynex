package com.cynex.data.local.datastore

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "cynex_prefs")

@Singleton
class UserPreferences @Inject constructor(@ApplicationContext private val context: Context) {

    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[PreferenceKeys.ONBOARDING_DONE] ?: false }
    val temperature: Flow<Float> = context.dataStore.data.map { it[PreferenceKeys.TEMPERATURE] ?: 0.7f }
    val maxTokens: Flow<Int> = context.dataStore.data.map { it[PreferenceKeys.MAX_TOKENS] ?: 512 }
    val wakeWordEnabled: Flow<Boolean> = context.dataStore.data.map { it[PreferenceKeys.WAKE_WORD_ENABLED] ?: false }
    val overlayEnabled: Flow<Boolean> = context.dataStore.data.map { it[PreferenceKeys.OVERLAY_ENABLED] ?: false }
    val activeModelPath: Flow<String?> = context.dataStore.data.map { it[PreferenceKeys.ACTIVE_MODEL_PATH] }

    suspend fun setOnboardingDone(value: Boolean) = context.dataStore.edit { it[PreferenceKeys.ONBOARDING_DONE] = value }
    suspend fun setTemperature(v: Float) = context.dataStore.edit { it[PreferenceKeys.TEMPERATURE] = v }
    suspend fun setMaxTokens(v: Int) = context.dataStore.edit { it[PreferenceKeys.MAX_TOKENS] = v }
    suspend fun setWakeWordEnabled(v: Boolean) = context.dataStore.edit { it[PreferenceKeys.WAKE_WORD_ENABLED] = v }
    suspend fun setOverlayEnabled(v: Boolean) = context.dataStore.edit { it[PreferenceKeys.OVERLAY_ENABLED] = v }
    suspend fun setActiveModelPath(path: String?) = context.dataStore.edit {
        if (path == null) it.remove(PreferenceKeys.ACTIVE_MODEL_PATH) else it[PreferenceKeys.ACTIVE_MODEL_PATH] = path
    }
}

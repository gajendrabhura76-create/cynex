package com.cynex.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cynex.ui.screens.AutomationSettingsScreen
import com.cynex.ui.screens.ChatScreen
import com.cynex.ui.screens.ModelManagerScreen
import com.cynex.ui.screens.OnboardingScreen
import com.cynex.ui.screens.PermissionManagementScreen
import com.cynex.ui.screens.PermissionSetupScreen
import com.cynex.ui.screens.SettingsScreen
import com.cynex.ui.screens.SplashScreen
import com.cynex.ui.screens.VoiceSettingsScreen

@Composable
fun CynexNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(
        navController = navController,
        startDestination = Routes.SPLASH,
        enterTransition = { slideInHorizontally(animationSpec = tween(280)) { it / 4 } + fadeIn(tween(280)) },
        exitTransition = { fadeOut(tween(180)) },
        popEnterTransition = { fadeIn(tween(180)) },
        popExitTransition = { slideOutHorizontally(animationSpec = tween(280)) { it / 4 } + fadeOut(tween(280)) }
    ) {
        composable(Routes.SPLASH) { SplashScreen(navController) }
        composable(Routes.ONBOARDING) { OnboardingScreen(navController) }
        composable(Routes.PERMISSIONS) { PermissionSetupScreen(navController) }
        composable(Routes.CHAT) { ChatScreen(navController) }
        composable(Routes.SETTINGS) { SettingsScreen(navController) }
        composable(Routes.MODELS) { ModelManagerScreen(navController) }
        composable(Routes.AUTOMATIONS) { AutomationSettingsScreen(navController) }
        composable(Routes.VOICE) { VoiceSettingsScreen(navController) }
        composable(Routes.PERMISSION_MGMT) { PermissionManagementScreen(navController) }
    }
}

package com.cynex.accessibility

import android.accessibilityservice.AccessibilityService
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TapController @Inject constructor(private val gestures: GestureController) {
    fun tap(x: Float, y: Float): Boolean {
        val svc = CynexAccessibilityService.instance ?: return false
        return svc.dispatchGesture(gestures.buildTap(x, y), null, null)
    }
}

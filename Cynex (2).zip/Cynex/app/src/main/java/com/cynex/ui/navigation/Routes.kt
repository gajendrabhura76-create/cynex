package com.cynex.ui.navigation

object Routes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val PERMISSIONS = "permissions"
    const val CHAT = "chat"
    const val SETTINGS = "settings"
    const val MODELS = "models"
    const val AUTOMATIONS = "automations"
    const val VOICE = "voice"
    const val PERMISSION_MGMT = "permission_mgmt"
}

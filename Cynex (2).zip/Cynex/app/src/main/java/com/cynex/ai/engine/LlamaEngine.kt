package com.cynex.ai.engine

import com.cynex.ai.models.ModelConfig
import com.cynex.core.utils.Logger
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Kotlin wrapper around the native llama.cpp engine.
 * The native methods are implemented in `cpp/llama_jni.cpp`.
 *
 * Make sure to clone llama.cpp into `app/src/main/cpp/llama.cpp`
 * before building. See README.md for instructions.
 */
@Singleton
class LlamaEngine @Inject constructor() {

    @Volatile private var ctxPtr: Long = 0L
    @Volatile var loadedConfig: ModelConfig? = null
        private set

    init {
        try {
            System.loadLibrary("cynex-llama")
            Logger.i("Loaded native cynex-llama library")
        } catch (t: Throwable) {
            Logger.w("Native cynex-llama library not available; running in stub mode", t)
        }
    }

    fun load(config: ModelConfig): Boolean {
        unload()
        return try {
            ctxPtr = nativeLoadModel(
                config.path, config.contextSize, config.nThreads, config.nGpuLayers
            )
            val ok = ctxPtr != 0L
            if (ok) loadedConfig = config
            ok
        } catch (t: UnsatisfiedLinkError) {
            Logger.w("llama.cpp native lib not built — using stub mode")
            ctxPtr = STUB_CTX
            loadedConfig = config
            true
        }
    }

    fun unload() {
        if (ctxPtr != 0L && ctxPtr != STUB_CTX) {
            try { nativeFreeModel(ctxPtr) } catch (_: Throwable) {}
        }
        ctxPtr = 0L
        loadedConfig = null
    }

    fun isLoaded(): Boolean = ctxPtr != 0L

    fun generateStream(prompt: String, config: ModelConfig): Flow<String> = flow {
        if (!isLoaded()) {
            emit("[error] No model loaded. Open Settings → Model Manager and load a GGUF file.")
            return@flow
        }
        if (ctxPtr == STUB_CTX) {
            // Stub: simulate streaming until native library is built.
            val msg = "I'm Cynex (stub mode). The native llama.cpp library is not built yet. " +
                "Add llama.cpp to app/src/main/cpp/ and rebuild to enable on-device inference. " +
                "You said: \"$prompt\"."
            for (token in msg.split(" ")) {
                emit("$token ")
                kotlinx.coroutines.delay(40)
            }
            return@flow
        }
        val sessionId = nativeStartCompletion(
            ctxPtr, prompt, config.maxTokens,
            config.temperature, config.topP, config.topK, config.repeatPenalty
        )
        try {
            while (true) {
                val token = nativeNextToken(ctxPtr, sessionId) ?: break
                if (token.isEmpty()) break
                emit(token)
            }
        } finally {
            nativeEndCompletion(ctxPtr, sessionId)
        }
    }.flowOn(Dispatchers.Default)

    private external fun nativeLoadModel(
        path: String, ctxSize: Int, nThreads: Int, nGpuLayers: Int
    ): Long
    private external fun nativeFreeModel(ctx: Long)
    private external fun nativeStartCompletion(
        ctx: Long, prompt: String, maxTokens: Int,
        temp: Float, topP: Float, topK: Int, repeatPenalty: Float
    ): Long
    private external fun nativeNextToken(ctx: Long, sessionId: Long): String?
    private external fun nativeEndCompletion(ctx: Long, sessionId: Long)

    companion object {
        private const val STUB_CTX = -1L
    }
}

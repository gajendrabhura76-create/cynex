package com.cynex.automation.triggers
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AppOpenTrigger @Inject constructor() {
    fun matches(currentPkg: String, watchPkg: String) = currentPkg == watchPkg
}

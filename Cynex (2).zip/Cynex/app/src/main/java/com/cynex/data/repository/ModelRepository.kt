package com.cynex.data.repository

import android.content.Context
import com.cynex.ai.engine.GGUFLoader
import com.cynex.ai.models.ModelConfig
import com.cynex.data.local.database.ModelDao
import com.cynex.data.local.entities.ModelEntity
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModelRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dao: ModelDao,
    private val loader: GGUFLoader
) {
    fun observe(): Flow<List<ModelConfig>> = dao.observeAll().map { list ->
        list.map { ModelConfig(it.name, it.path, it.contextSize, temperature = it.temperature, maxTokens = it.maxTokens) }
    }

    suspend fun importLocal(uri: android.net.Uri, displayName: String): ModelConfig? {
        val cfg = loader.importFromUri(context, uri, displayName) ?: return null
        dao.upsert(ModelEntity(cfg.path, cfg.name, cfg.contextSize, cfg.temperature, cfg.maxTokens))
        return cfg
    }

    suspend fun setActive(path: String) = dao.setActive(path)
    suspend fun delete(path: String) = dao.delete(path)
}

package com.cynex.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.cynex.core.utils.Logger
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TextToSpeechManager @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false

    fun init(onReady: () -> Unit = {}) {
        if (tts != null) { onReady(); return }
        tts = TextToSpeech(context) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.language = Locale.getDefault()
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {}
                @Deprecated("deprecated") override fun onError(utteranceId: String?) {
                    Logger.w("TTS error: $utteranceId")
                }
            })
            if (ready) onReady()
        }
    }

    fun speak(text: String) {
        if (!ready) init { speakNow(text) } else speakNow(text)
    }

    private fun speakNow(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cynex-${System.currentTimeMillis()}")
    }

    fun stop() = tts?.stop()
    fun shutdown() { tts?.shutdown(); tts = null; ready = false }
}

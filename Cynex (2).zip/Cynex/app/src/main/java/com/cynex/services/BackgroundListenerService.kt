package com.cynex.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.cynex.core.managers.NotificationManager
import com.cynex.voice.SpeechRecognizerManager
import com.cynex.voice.WakeWordDetector
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class BackgroundListenerService : Service() {

    @Inject lateinit var notif: NotificationManager
    @Inject lateinit var stt: SpeechRecognizerManager
    @Inject lateinit var wake: WakeWordDetector
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var job: Job? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(3001, notif.assistantNotification("Listening for \"Hey Cynex\""))
        stt.start()
        job = scope.launch {
            stt.results.collect { transcript ->
                if (wake.isWakeWord(transcript)) {
                    sendBroadcast(Intent("com.cynex.WAKE_DETECTED").putExtra("text", wake.strip(transcript)))
                }
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() { job?.cancel(); stt.stop(); super.onDestroy() }
}

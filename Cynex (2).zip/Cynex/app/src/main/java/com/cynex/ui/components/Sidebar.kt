package com.cynex.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.cynex.ui.theme.CynexAccent
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexSurface
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim

@Composable
fun CynexSidebar(
    sessions: List<String>,
    onNewChat: () -> Unit,
    onOpenSettings: () -> Unit,
    onSessionSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(280.dp)
            .background(CynexBg)
            .padding(16.dp)
    ) {
        Text("Cynex", color = CynexText, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(CynexAccent.copy(alpha = 0.15f))
                .clickable { onNewChat() }
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Add, contentDescription = null, tint = CynexAccent)
            Spacer(Modifier.width(8.dp))
            Text("New chat", color = CynexText)
        }
        Spacer(Modifier.height(20.dp))
        Text("History", color = CynexTextDim, style = MaterialTheme.typography.labelMedium)
        Spacer(Modifier.height(8.dp))
        LazyColumn(modifier = Modifier.weight(1f)) {
            items(sessions) { id ->
                Text(
                    "Session ${id.take(6)}",
                    color = CynexText,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSessionSelected(id) }
                        .padding(vertical = 10.dp)
                )
            }
        }
        Divider(color = CynexSurface)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenSettings() }
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Outlined.Settings, contentDescription = null, tint = CynexTextDim)
            Spacer(Modifier.width(8.dp))
            Text("Settings", color = CynexText)
        }
    }
}

package com.cynex.automation.executor

import com.cynex.accessibility.AutomationExecutor
import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ActionExecutor @Inject constructor(
    private val automation: AutomationExecutor
) {
    suspend fun run(action: Action): Boolean = automation.run(action)
}

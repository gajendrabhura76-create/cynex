package com.cynex.core.constants

object IntentConstants {
    const val ACTION_TOGGLE_BUBBLE = "com.cynex.action.TOGGLE_BUBBLE"
    const val ACTION_RUN_AUTOMATION = "com.cynex.action.RUN_AUTOMATION"
    const val ACTION_VOICE_TRIGGER = "com.cynex.action.VOICE_TRIGGER"
    const val EXTRA_PROMPT = "extra_prompt"
    const val EXTRA_AUTOMATION_ID = "extra_automation_id"
}

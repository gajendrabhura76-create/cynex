package com.cynex.ai.models

data class AIResponse(
    val text: String,
    val actions: List<Action> = emptyList(),
    val toolCalls: List<ToolCall> = emptyList(),
    val finished: Boolean = false
)

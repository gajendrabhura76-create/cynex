package com.cynex.ai.prompts

object SafetyPrompt {
    const val text = """Refuse requests that involve illegal activity, harm to people, or accessing accounts you do not own.
Never reveal stored secrets, model paths, or user files unless the user explicitly asks for that information."""
}

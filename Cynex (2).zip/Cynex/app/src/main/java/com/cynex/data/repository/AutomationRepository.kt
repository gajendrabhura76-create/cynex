package com.cynex.data.repository

import com.cynex.data.local.database.AutomationDao
import com.cynex.data.local.entities.AutomationEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutomationRepository @Inject constructor(private val dao: AutomationDao) {
    fun observe(): Flow<List<AutomationEntity>> = dao.observeAll()
    suspend fun add(entity: AutomationEntity) = dao.insert(entity)
    suspend fun delete(id: Long) = dao.delete(id)
}

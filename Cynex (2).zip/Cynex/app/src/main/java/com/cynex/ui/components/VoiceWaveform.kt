package com.cynex.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun VoiceWaveform(
    amplitudes: List<Float>,
    color: Color = Color(0xFF00E5FF),
    modifier: Modifier = Modifier,
    barCount: Int = 32
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f, targetValue = (2 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "phase"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(48.dp)) {
        val barW = (size.width / barCount) * 0.6f
        val gap = size.width / barCount
        val maxH = size.height

        for (i in 0 until barCount) {
            val amp = if (amplitudes.size > i) amplitudes[i] else 0f
            val idleH = abs(sin(i * 0.4f + phase)) * maxH * 0.25f
            val voiceH = amp * maxH
            val barH = (idleH + voiceH).coerceIn(4f, maxH)
            val x = i * gap + gap / 2f - barW / 2f
            val y = (maxH - barH) / 2f
            val alpha = 0.5f + amp * 0.5f
            drawRoundRect(
                color = color.copy(alpha = alpha),
                topLeft = Offset(x, y),
                size = Size(barW, barH),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}

@Composable
fun SiriWaveform(
    amplitude: Float,
    color: Color = Color(0xFF00E5FF),
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "siriwave")
    val phase by infiniteTransition.animateFloat(
        0f, (2 * Math.PI).toFloat(),
        infiniteRepeatable(tween(800, easing = LinearEasing)), label = "p"
    )

    Canvas(modifier = modifier.fillMaxWidth().height(64.dp)) {
        val cx = size.width / 2f
        val cy = size.height / 2f
        val waves = listOf(
            Triple(1.0f, 0.0f, color.copy(alpha = 0.9f)),
            Triple(0.7f, 0.5f, color.copy(alpha = 0.6f)),
            Triple(0.4f, 1.0f, color.copy(alpha = 0.35f)),
            Triple(0.25f, 1.5f, color.copy(alpha = 0.2f)),
        )
        for ((scaleY, phaseOff, wcolor) in waves) {
            val path = androidx.compose.ui.graphics.Path()
            val steps = 200
            for (i in 0..steps) {
                val x = (i.toFloat() / steps) * size.width
                val t = (i.toFloat() / steps) * 2 * Math.PI.toFloat()
                val y = cy + sin(t * 4 + phase + phaseOff) * cy * scaleY * (0.3f + amplitude * 0.7f)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(
                path, color = wcolor,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f - phaseOff * 0.3f)
            )
        }
    }
}

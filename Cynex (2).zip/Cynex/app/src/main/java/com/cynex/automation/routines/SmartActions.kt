package com.cynex.automation.routines

import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SmartActions @Inject constructor() {
    fun goHome(): List<Action> = listOf(Action(Action.Type.HOME))
    fun back(): List<Action> = listOf(Action(Action.Type.BACK))
}

package com.cynex.ai.parser

import com.cynex.ai.models.AIResponse
import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ResponseParser @Inject constructor() {
    private val codeFence = Regex("```json[\\s\\S]*?```", RegexOption.IGNORE_CASE)

    fun parse(rawText: String, actions: List<Action>): AIResponse {
        val cleaned = rawText.replace(codeFence, "").trim()
        return AIResponse(text = cleaned, actions = actions, finished = true)
    }
}

package com.cynex.automation.triggers
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TimeTrigger @Inject constructor() {
    fun isWithin(nowMs: Long, targetMs: Long, windowMs: Long = 60_000L) =
        kotlin.math.abs(nowMs - targetMs) <= windowMs
}

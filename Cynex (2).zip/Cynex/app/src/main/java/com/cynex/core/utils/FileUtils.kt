package com.cynex.core.utils

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

object FileUtils {
    fun copyUriToInternal(context: Context, uri: Uri, dstName: String): File? {
        return try {
            val dst = File(context.filesDir, "models/$dstName").apply { parentFile?.mkdirs() }
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(dst).use { output -> input.copyTo(output) }
            }
            dst
        } catch (t: Throwable) {
            Logger.e("copyUriToInternal failed", t); null
        }
    }

    fun modelsDir(context: Context): File =
        File(context.filesDir, "models").apply { mkdirs() }
}

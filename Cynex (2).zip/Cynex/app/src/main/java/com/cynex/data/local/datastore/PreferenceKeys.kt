package com.cynex.data.local.datastore

import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey

object PreferenceKeys {
    val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
    val ACTIVE_MODEL_PATH = stringPreferencesKey("active_model_path")
    val TEMPERATURE = floatPreferencesKey("temperature")
    val MAX_TOKENS = intPreferencesKey("max_tokens")
    val WAKE_WORD_ENABLED = booleanPreferencesKey("wake_word_enabled")
    val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
    val DARK_MODE = booleanPreferencesKey("dark_mode")
}

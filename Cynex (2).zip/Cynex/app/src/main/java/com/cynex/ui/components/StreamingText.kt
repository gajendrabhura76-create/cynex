package com.cynex.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import com.cynex.ui.theme.CynexAccentAlt

@Composable
fun StreamingText(
    text: String,
    isStreaming: Boolean,
    style: TextStyle,
    color: Color
) {
    Row {
        Text(text, style = style, color = color)
        if (isStreaming) {
            val alpha by animateFloatAsState(
                targetValue = if (isStreaming) 1f else 0f,
                animationSpec = tween(500),
                label = "caret"
            )
            Text(" ▍", style = style, color = CynexAccentAlt, modifier = Modifier.alpha(alpha))
        }
    }
}

package com.cynex.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.cynex.ui.components.GlassCard
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim

@Composable
fun VoiceSettingsScreen(navController: NavHostController) {
    Scaffold(
        containerColor = CynexBg,
        topBar = {
            TopAppBar(
                title = { Text("Voice", color = CynexText) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CynexBg)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("Speech Recognition", color = CynexText, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Cynex uses your device's built-in speech recognizer for voice input.",
                        color = CynexTextDim, style = MaterialTheme.typography.bodyMedium)
                }
            }
            Spacer(Modifier.height(12.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    Text("Text-to-Speech", color = CynexText, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text("Responses are spoken using your system TTS engine. You can change voice & language in your phone's TTS settings.",
                        color = CynexTextDim, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

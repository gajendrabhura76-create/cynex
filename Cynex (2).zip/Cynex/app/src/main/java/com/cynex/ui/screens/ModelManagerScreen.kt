package com.cynex.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.cynex.ai.models.ModelConfig
import com.cynex.core.managers.ModelManager
import com.cynex.data.repository.ModelRepository
import com.cynex.ui.components.GlassCard
import com.cynex.ui.theme.CynexAccent
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ModelManagerViewModel @Inject constructor(
    private val repo: ModelRepository,
    private val modelManager: ModelManager
) : ViewModel() {

    val models: StateFlow<List<ModelConfig>> =
        repo.observe().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun import(uri: Uri, displayName: String) = viewModelScope.launch {
        repo.importLocal(uri, displayName)
    }
    fun setActive(cfg: ModelConfig) = viewModelScope.launch {
        repo.setActive(cfg.path); modelManager.load(cfg)
    }
    fun delete(cfg: ModelConfig) = viewModelScope.launch { repo.delete(cfg.path) }
}

@Composable
fun ModelManagerScreen(
    navController: NavHostController,
    vm: ModelManagerViewModel = hiltViewModel()
) {
    val models by vm.models.collectAsState()
    val context = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val name = uri.lastPathSegment?.substringAfterLast('/') ?: "model.gguf"
            vm.import(uri, if (name.endsWith(".gguf", true)) name else "$name.gguf")
        }
    }

    Scaffold(
        containerColor = CynexBg,
        topBar = {
            TopAppBar(
                title = { Text("AI Models", color = CynexText) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CynexBg)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { picker.launch(arrayOf("application/octet-stream", "*/*")) },
                containerColor = CynexAccent,
                icon = { Icon(Icons.Outlined.Add, contentDescription = null) },
                text = { Text("Add GGUF") }
            )
        }
    ) { padding ->
        if (models.isEmpty()) {
            Column(Modifier.padding(padding).padding(24.dp).fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No models yet", color = CynexText, style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(8.dp))
                Text("Add a .gguf file (e.g. DeepSeek R1 Distill 1.5B) using the button below.",
                     color = CynexTextDim, style = MaterialTheme.typography.bodyMedium)
            }
        } else {
            LazyColumn(Modifier.padding(padding).fillMaxSize().padding(12.dp)) {
                items(models) { cfg ->
                    GlassCard(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { vm.setActive(cfg) }) {
                                Text(cfg.name, color = CynexText, style = MaterialTheme.typography.titleMedium)
                                Text(cfg.path, color = CynexTextDim, style = MaterialTheme.typography.bodySmall)
                            }
                            IconButton(onClick = { vm.delete(cfg) }) {
                                Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = CynexTextDim)
                            }
                        }
                    }
                }
            }
        }
    }
}

package com.cynex.overlay

import android.content.Context
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Minimal in-overlay chat preview shown when bubble is expanded.
 * Real interactive chat lives in MainActivity; this is a quick peek.
 */
class OverlayChatWindow(context: Context) : LinearLayout(context) {
    private val title = TextView(context).apply { text = "Cynex"; textSize = 18f }
    private val body = TextView(context).apply { text = "Tap the bubble to open the full assistant." }

    init {
        orientation = VERTICAL
        setPadding(32, 32, 32, 32)
        addView(title); addView(body)
    }
}

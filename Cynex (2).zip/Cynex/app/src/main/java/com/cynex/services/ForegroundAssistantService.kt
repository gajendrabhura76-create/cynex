package com.cynex.services

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.cynex.core.managers.NotificationManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class ForegroundAssistantService : Service() {

    @Inject lateinit var notif: NotificationManager

    override fun onCreate() {
        super.onCreate()
        startForeground(1001, notif.assistantNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
}

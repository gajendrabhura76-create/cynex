package com.cynex.ai.models

import kotlinx.serialization.Serializable

@Serializable
data class Action(
    val type: Type,
    val target: String? = null,
    val text: String? = null,
    val x: Float? = null,
    val y: Float? = null,
    val direction: String? = null
) {
    enum class Type {
        OPEN_APP, TAP, SCROLL, TYPE_TEXT, OPEN_SETTINGS,
        TOGGLE_BLUETOOTH, TOGGLE_WIFI, READ_NOTIFICATIONS,
        REPLY_MESSAGE, BACK, HOME, RECENT, NONE
    }
}

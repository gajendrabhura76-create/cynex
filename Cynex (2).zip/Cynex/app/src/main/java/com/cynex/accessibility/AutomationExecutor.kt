package com.cynex.accessibility

import com.cynex.ai.models.Action
import com.cynex.ai.tools.PhoneTool
import kotlinx.coroutines.delay
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutomationExecutor @Inject constructor(
    private val tap: TapController,
    private val scroll: ScrollController,
    private val text: TextInputController,
    private val launcher: AppLauncher,
    private val actions: AccessibilityActions,
    private val phoneTool: PhoneTool
) {
    suspend fun runBatch(list: List<Action>): List<Boolean> = list.map { run(it) }

    suspend fun run(action: Action): Boolean {
        val ok = when (action.type) {
            Action.Type.OPEN_APP -> action.target?.let { launcher.launchByName(it) } ?: false
            Action.Type.TAP -> {
                val x = action.x ?: return false
                val y = action.y ?: return false
                tap.tap(x, y)
            }
            Action.Type.SCROLL -> {
                val dir = when (action.direction?.lowercase()) {
                    "up" -> ScrollController.Direction.UP
                    "left" -> ScrollController.Direction.LEFT
                    "right" -> ScrollController.Direction.RIGHT
                    else -> ScrollController.Direction.DOWN
                }
                scroll.scroll(dir)
            }
            Action.Type.TYPE_TEXT -> action.text?.let { text.typeIntoFocusedField(it) } ?: false
            Action.Type.OPEN_SETTINGS -> { phoneTool.openSettings(); true }
            Action.Type.TOGGLE_BLUETOOTH -> { phoneTool.openBluetooth(); true }
            Action.Type.TOGGLE_WIFI -> { phoneTool.openWifi(); true }
            Action.Type.READ_NOTIFICATIONS -> actions.notifications()
            Action.Type.REPLY_MESSAGE -> action.text?.let { text.typeIntoFocusedField(it) } ?: false
            Action.Type.BACK -> actions.back()
            Action.Type.HOME -> actions.home()
            Action.Type.RECENT -> actions.recents()
            Action.Type.NONE -> true
        }
        delay(220)
        return ok
    }
}

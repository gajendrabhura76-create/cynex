package com.cynex.ui.theme

import androidx.compose.ui.graphics.Color

val CynexBg          = Color(0xFF0A0A0F)
val CynexSurface     = Color(0xFF11111A)
val CynexSurfaceAlt  = Color(0xFF181826)
val CynexBorder      = Color(0xFF22223A)
val CynexAccent      = Color(0xFF7C5CFF)
val CynexAccentAlt   = Color(0xFF22D3EE)
val CynexAccentSoft  = Color(0xFF332B66)
val CynexText        = Color(0xFFF5F5FA)
val CynexTextDim     = Color(0xFFB7B7C9)
val CynexDanger      = Color(0xFFFF5C7A)
val CynexSuccess     = Color(0xFF36D399)

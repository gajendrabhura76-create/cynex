package com.cynex.ai.models

import kotlinx.serialization.Serializable

@Serializable
data class ModelConfig(
    val name: String,
    val path: String,
    val contextSize: Int = 2048,
    val nThreads: Int = 4,
    val nGpuLayers: Int = 0,
    val temperature: Float = 0.7f,
    val topP: Float = 0.9f,
    val topK: Int = 40,
    val maxTokens: Int = 512,
    val repeatPenalty: Float = 1.1f
)

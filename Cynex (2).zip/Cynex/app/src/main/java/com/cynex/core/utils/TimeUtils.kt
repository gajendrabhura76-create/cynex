package com.cynex.core.utils

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object TimeUtils {
    private val fmt = SimpleDateFormat("MMM d, HH:mm", Locale.getDefault())
    fun format(ts: Long): String = fmt.format(Date(ts))
    fun now(): Long = System.currentTimeMillis()
}

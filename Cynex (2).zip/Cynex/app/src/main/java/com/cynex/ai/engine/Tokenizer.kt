package com.cynex.ai.engine

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Approximate token counter (4 chars ≈ 1 token).
 * Real tokenization happens in native code at inference time.
 */
@Singleton
class Tokenizer @Inject constructor() {
    fun approxCount(text: String): Int = (text.length / 4).coerceAtLeast(1)
}

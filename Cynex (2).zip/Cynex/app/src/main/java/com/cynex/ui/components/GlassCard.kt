package com.cynex.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.cynex.ui.theme.CynexBorder
import com.cynex.ui.theme.CynexSurface
import com.cynex.ui.theme.CynexSurfaceAlt

@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(
                Brush.linearGradient(listOf(CynexSurface.copy(alpha = 0.95f), CynexSurfaceAlt.copy(alpha = 0.95f)))
            )
            .border(1.dp, CynexBorder.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) { content() }
}

package com.cynex.voice

import com.cynex.core.constants.AppConstants
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lightweight string-match wake word detector.
 * For accurate always-on wake-word, integrate Porcupine or a small KWS model.
 */
@Singleton
class WakeWordDetector @Inject constructor() {
    fun isWakeWord(text: String): Boolean =
        text.lowercase().contains(AppConstants.WAKE_WORD)

    fun strip(text: String): String =
        text.lowercase().replace(AppConstants.WAKE_WORD, "").trim()
}

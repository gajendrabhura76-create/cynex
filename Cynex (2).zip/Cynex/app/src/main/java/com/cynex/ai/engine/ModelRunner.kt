package com.cynex.ai.engine

import com.cynex.ai.memory.ConversationMemory
import com.cynex.ai.models.AIResponse
import com.cynex.ai.models.ModelConfig
import com.cynex.ai.parser.ActionExtractor
import com.cynex.ai.parser.ResponseParser
import com.cynex.ai.prompts.SystemPrompt
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModelRunner @Inject constructor(
    private val engine: LlamaEngine,
    private val memory: ConversationMemory,
    private val formatter: PromptFormatter,
    private val parser: ResponseParser,
    private val actionExtractor: ActionExtractor
) {
    fun chatStream(userText: String, config: ModelConfig): Flow<AIResponse> = flow {
        memory.appendUser(userText)
        val prompt = formatter.format(SystemPrompt.text, memory.snapshot())
        val sb = StringBuilder()
        engine.generateStream(prompt, config).collect { tok ->
            sb.append(tok)
            emit(AIResponse(text = sb.toString(), finished = false))
        }
        val full = sb.toString()
        val actions = actionExtractor.extract(full)
        memory.appendAssistant(full)
        emit(parser.parse(full, actions))
    }
}

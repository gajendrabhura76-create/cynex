package com.cynex.automation.scheduler

import android.content.Context
import androidx.work.WorkManager
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class WorkerManager @Inject constructor(@ApplicationContext private val context: Context) {
    fun cancelAll(tag: String) = WorkManager.getInstance(context).cancelAllWorkByTag(tag)
}

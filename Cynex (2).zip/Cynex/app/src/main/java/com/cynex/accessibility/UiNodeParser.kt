package com.cynex.accessibility

import android.view.accessibility.AccessibilityNodeInfo
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class UiNodeParser @Inject constructor() {
    fun findClickableByText(label: String): AccessibilityNodeInfo? {
        val root = CynexAccessibilityService.instance?.rootInActiveWindow ?: return null
        return walk(root) { node ->
            node.isClickable &&
                (node.text?.toString()?.equals(label, true) == true ||
                 node.contentDescription?.toString()?.equals(label, true) == true)
        }
    }

    private fun walk(node: AccessibilityNodeInfo, predicate: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (predicate(node)) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            walk(child, predicate)?.let { return it }
        }
        return null
    }
}

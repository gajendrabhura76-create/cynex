package com.cynex.overlay

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.view.setMargins
import com.cynex.MainActivity
import com.cynex.R
import com.cynex.core.managers.NotificationManager
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class FloatingBubbleService : Service() {

    @Inject lateinit var notif: NotificationManager
    private var wm: WindowManager? = null
    private var bubble: View? = null
    private val params: WindowManager.LayoutParams by lazy {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 50; y = 300
        }
    }

    override fun onCreate() {
        super.onCreate()
        startForeground(2001, notif.assistantNotification("Floating bubble active"))
        attachBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    private fun attachBubble() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val container = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(160, 160)
            setBackgroundResource(R.drawable.bubble_bg)
        }
        val icon = ImageView(this).apply {
            setImageResource(R.drawable.ic_launcher_foreground)
            layoutParams = FrameLayout.LayoutParams(120, 120, Gravity.CENTER)
        }
        container.addView(icon)
        bubble = container
        BubbleDragHandler.attach(container, params, wm!!) { openApp() }
        wm!!.addView(container, params)
    }

    private fun openApp() {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    override fun onDestroy() {
        bubble?.let { runCatching { wm?.removeView(it) } }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

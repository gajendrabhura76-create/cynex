package com.cynex.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Chat
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController

data class BottomDest(val route: String, val label: String)

@Composable
fun CynexBottomBar(
    navController: NavHostController,
    currentRoute: String?
) {
    val items = listOf(
        BottomDest(Routes.CHAT, "Chat"),
        BottomDest(Routes.VOICE, "Voice"),
        BottomDest(Routes.SETTINGS, "Settings")
    )
    NavigationBar {
        items.forEach { dest ->
            NavigationBarItem(
                selected = currentRoute == dest.route,
                onClick = { if (currentRoute != dest.route) navController.navigate(dest.route) },
                icon = {
                    val icon = when (dest.route) {
                        Routes.CHAT -> Icons.Outlined.Chat
                        Routes.VOICE -> Icons.Outlined.Mic
                        else -> Icons.Outlined.Settings
                    }
                    Icon(icon, contentDescription = dest.label)
                },
                label = { Text(dest.label) }
            )
        }
    }
}

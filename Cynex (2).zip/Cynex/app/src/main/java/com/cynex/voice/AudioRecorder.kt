package com.cynex.voice

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AudioRecorder @Inject constructor() {
    private var record: AudioRecord? = null
    fun isRecording(): Boolean = record?.recordingState == AudioRecord.RECORDSTATE_RECORDING

    fun start(sampleRate: Int = 16000) {
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        record = AudioRecord(
            MediaRecorder.AudioSource.MIC, sampleRate,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf
        ).also { it.startRecording() }
    }

    fun stop() {
        try { record?.stop() } catch (_: Throwable) {}
        record?.release()
        record = null
    }
}

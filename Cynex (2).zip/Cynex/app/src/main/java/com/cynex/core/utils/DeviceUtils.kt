package com.cynex.core.utils

import android.app.ActivityManager
import android.content.Context
import android.os.Build

object DeviceUtils {
    fun totalRamMb(context: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        (context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        return mi.totalMem / (1024 * 1024)
    }

    fun deviceLabel(): String = "${Build.MANUFACTURER} ${Build.MODEL} (API ${Build.VERSION.SDK_INT})"
}

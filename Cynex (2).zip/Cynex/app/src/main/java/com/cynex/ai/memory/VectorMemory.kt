package com.cynex.ai.memory

import javax.inject.Inject
import javax.inject.Singleton

/**
 * Lightweight long-term memory placeholder.
 * For real semantic search, plug in an on-device embedding model.
 */
@Singleton
class VectorMemory @Inject constructor() {
    private val notes = mutableListOf<String>()
    fun remember(text: String) { synchronized(notes) { notes.add(text) } }
    fun recall(query: String, topK: Int = 3): List<String> {
        val q = query.lowercase()
        return notes.filter { it.lowercase().contains(q) }.take(topK)
    }
    fun clear() { synchronized(notes) { notes.clear() } }
}

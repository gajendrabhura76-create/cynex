package com.cynex.core.security

import android.content.Context
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecurePrefs @Inject constructor(
    @ApplicationContext private val context: Context,
    encryptionManager: EncryptionManager
) {
    private val prefs = encryptionManager.securePrefs(context)

    fun put(key: String, value: String) = prefs.edit().putString(key, value).apply()
    fun get(key: String, default: String? = null): String? = prefs.getString(key, default)
    fun remove(key: String) = prefs.edit().remove(key).apply()
    fun clear() = prefs.edit().clear().apply()
}

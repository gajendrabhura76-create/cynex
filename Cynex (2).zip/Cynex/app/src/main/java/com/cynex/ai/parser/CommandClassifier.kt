package com.cynex.ai.parser

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CommandClassifier @Inject constructor() {
    enum class Kind { CHAT, COMMAND, AUTOMATION }

    fun classify(text: String): Kind {
        val t = text.lowercase()
        return when {
            t.startsWith("/") -> Kind.COMMAND
            t.startsWith("automate ") || t.startsWith("routine ") -> Kind.AUTOMATION
            else -> Kind.CHAT
        }
    }
}

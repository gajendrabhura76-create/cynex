package com.cynex.core.di

import android.content.Context
import androidx.room.Room
import com.cynex.core.constants.AppConstants
import com.cynex.data.local.database.AutomationDao
import com.cynex.data.local.database.ChatDao
import com.cynex.data.local.database.CynexDatabase
import com.cynex.data.local.database.ModelDao
import com.cynex.data.local.database.SettingsDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {
    @Provides @Singleton
    fun provideDb(@ApplicationContext ctx: Context): CynexDatabase =
        Room.databaseBuilder(ctx, CynexDatabase::class.java, AppConstants.DB_NAME)
            .fallbackToDestructiveMigration().build()

    @Provides fun chatDao(db: CynexDatabase): ChatDao = db.chatDao()
    @Provides fun settingsDao(db: CynexDatabase): SettingsDao = db.settingsDao()
    @Provides fun automationDao(db: CynexDatabase): AutomationDao = db.automationDao()
    @Provides fun modelDao(db: CynexDatabase): ModelDao = db.modelDao()
}

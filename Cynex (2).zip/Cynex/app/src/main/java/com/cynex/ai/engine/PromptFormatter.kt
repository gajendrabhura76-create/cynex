package com.cynex.ai.engine

import com.cynex.ai.models.ChatMessage
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Formats prompts for DeepSeek-style chat templates.
 */
@Singleton
class PromptFormatter @Inject constructor() {
    fun format(systemPrompt: String, history: List<ChatMessage>): String {
        val sb = StringBuilder()
        sb.append("<|begin▁of▁sentence|>")
        sb.append(systemPrompt).append("\n\n")
        for (msg in history) {
            when (msg.role) {
                ChatMessage.Role.USER ->
                    sb.append("<|User|>").append(msg.content).append("\n")
                ChatMessage.Role.ASSISTANT ->
                    sb.append("<|Assistant|>").append(msg.content).append("\n")
                ChatMessage.Role.SYSTEM ->
                    sb.append(msg.content).append("\n")
            }
        }
        sb.append("<|Assistant|>")
        return sb.toString()
    }
}

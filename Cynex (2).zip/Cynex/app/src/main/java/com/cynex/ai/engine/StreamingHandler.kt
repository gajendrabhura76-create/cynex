package com.cynex.ai.engine

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StreamingHandler @Inject constructor() {
    fun rateLimit(source: Flow<String>, minDelayMs: Long = 12L): Flow<String> = flow {
        var last = 0L
        source.collect { token ->
            val now = System.currentTimeMillis()
            val wait = minDelayMs - (now - last)
            if (wait > 0) kotlinx.coroutines.delay(wait)
            last = System.currentTimeMillis()
            emit(token)
        }
    }
}

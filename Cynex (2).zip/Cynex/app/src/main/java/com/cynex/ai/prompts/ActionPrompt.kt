package com.cynex.ai.prompts

object ActionPrompt {
    fun explain(actionType: String, target: String?): String =
        when (actionType) {
            "OPEN_APP" -> "Opening ${target ?: "app"}…"
            "SCROLL" -> "Scrolling…"
            "TAP" -> "Tapping…"
            "TYPE_TEXT" -> "Typing…"
            "OPEN_SETTINGS" -> "Opening Settings…"
            "TOGGLE_BLUETOOTH" -> "Toggling Bluetooth…"
            "TOGGLE_WIFI" -> "Toggling Wi-Fi…"
            else -> "Working on it…"
        }
}

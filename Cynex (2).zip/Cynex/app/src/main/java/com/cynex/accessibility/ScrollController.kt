package com.cynex.accessibility

import android.content.res.Resources
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScrollController @Inject constructor(private val gestures: GestureController) {

    enum class Direction { UP, DOWN, LEFT, RIGHT }

    fun scroll(direction: Direction): Boolean {
        val svc = CynexAccessibilityService.instance ?: return false
        val dm = Resources.getSystem().displayMetrics
        val cx = dm.widthPixels / 2f
        val cy = dm.heightPixels / 2f
        val (sx, sy, ex, ey) = when (direction) {
            Direction.UP    -> floatArrayOf(cx, cy + 300, cx, cy - 300).let { Quad(it[0], it[1], it[2], it[3]) }
            Direction.DOWN  -> floatArrayOf(cx, cy - 300, cx, cy + 300).let { Quad(it[0], it[1], it[2], it[3]) }
            Direction.LEFT  -> floatArrayOf(cx + 300, cy, cx - 300, cy).let { Quad(it[0], it[1], it[2], it[3]) }
            Direction.RIGHT -> floatArrayOf(cx - 300, cy, cx + 300, cy).let { Quad(it[0], it[1], it[2], it[3]) }
        }
        return svc.dispatchGesture(gestures.buildSwipe(sx, sy, ex, ey), null, null)
    }

    private data class Quad(val a: Float, val b: Float, val c: Float, val d: Float) {
        operator fun component1() = a; operator fun component2() = b
        operator fun component3() = c; operator fun component4() = d
    }
}

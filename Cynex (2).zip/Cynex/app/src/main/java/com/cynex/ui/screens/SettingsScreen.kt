package com.cynex.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ArrowForwardIos
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.cynex.data.local.datastore.UserPreferences
import com.cynex.ui.components.GlassCard
import com.cynex.ui.navigation.Routes
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val prefs: UserPreferences
) : ViewModel() {
    val temperature: StateFlow<Float> =
        prefs.temperature.stateIn(viewModelScope, SharingStarted.Eagerly, 0.7f)
    val maxTokens: StateFlow<Int> =
        prefs.maxTokens.stateIn(viewModelScope, SharingStarted.Eagerly, 512)
    val wakeWord: StateFlow<Boolean> =
        prefs.wakeWordEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)
    val overlay: StateFlow<Boolean> =
        prefs.overlayEnabled.stateIn(viewModelScope, SharingStarted.Eagerly, false)

    fun setTemperature(v: Float) = viewModelScope.launch { prefs.setTemperature(v) }
    fun setMaxTokens(v: Int) = viewModelScope.launch { prefs.setMaxTokens(v) }
    fun setWakeWord(v: Boolean) = viewModelScope.launch { prefs.setWakeWordEnabled(v) }
    fun setOverlay(v: Boolean) = viewModelScope.launch { prefs.setOverlayEnabled(v) }
}

@Composable
fun SettingsScreen(
    navController: NavHostController,
    vm: SettingsViewModel = hiltViewModel()
) {
    val temperature by vm.temperature.collectAsState()
    val maxTokens by vm.maxTokens.collectAsState()
    val wakeWord by vm.wakeWord.collectAsState()
    val overlay by vm.overlay.collectAsState()

    Scaffold(
        containerColor = CynexBg,
        topBar = {
            TopAppBar(
                title = { Text("Settings", color = CynexText) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CynexBg)
            )
        }
    ) { padding ->
        Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {

            Text("AI", color = CynexTextDim, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    SettingsRow("Add / Manage Local Models") { navController.navigate(Routes.MODELS) }
                    Divider(color = CynexBg)
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Text("Temperature: ${"%.2f".format(temperature)}", color = CynexText)
                        Slider(value = temperature, onValueChange = vm::setTemperature, valueRange = 0f..1.5f)
                    }
                    Divider(color = CynexBg)
                    Column(Modifier.padding(vertical = 8.dp)) {
                        Text("Max tokens: $maxTokens", color = CynexText)
                        Slider(
                            value = maxTokens.toFloat(),
                            onValueChange = { vm.setMaxTokens(it.toInt()) },
                            valueRange = 64f..2048f, steps = 30
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Voice & Overlay", color = CynexTextDim, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    ToggleRow("Wake word ('Hey Cynex')", wakeWord, vm::setWakeWord)
                    Divider(color = CynexBg)
                    ToggleRow("Floating overlay bubble", overlay, vm::setOverlay)
                    Divider(color = CynexBg)
                    SettingsRow("Voice Settings") { navController.navigate(Routes.VOICE) }
                }
            }

            Spacer(Modifier.height(16.dp))
            Text("Automation", color = CynexTextDim, style = MaterialTheme.typography.labelMedium)
            Spacer(Modifier.height(6.dp))
            GlassCard(Modifier.fillMaxWidth()) {
                Column {
                    SettingsRow("Automation Routines") { navController.navigate(Routes.AUTOMATIONS) }
                    Divider(color = CynexBg)
                    SettingsRow("Permissions") { navController.navigate(Routes.PERMISSION_MGMT) }
                }
            }
        }
    }
}

@Composable
private fun SettingsRow(title: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onClick() }.padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = CynexText, modifier = Modifier.weight(1f))
        Icon(Icons.Outlined.ArrowForwardIos, contentDescription = null, tint = CynexTextDim)
    }
}

@Composable
private fun ToggleRow(title: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = CynexText, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

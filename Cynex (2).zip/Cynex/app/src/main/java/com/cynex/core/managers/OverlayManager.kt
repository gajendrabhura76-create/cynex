package com.cynex.core.managers

import android.content.Context
import android.content.Intent
import com.cynex.overlay.FloatingBubbleService
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class OverlayManager @Inject constructor(@ApplicationContext private val context: Context) {
    fun start() = context.startForegroundService(Intent(context, FloatingBubbleService::class.java))
    fun stop() = context.stopService(Intent(context, FloatingBubbleService::class.java))
}

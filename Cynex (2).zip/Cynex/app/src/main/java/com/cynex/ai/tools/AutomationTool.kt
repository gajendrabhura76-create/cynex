package com.cynex.ai.tools

import com.cynex.ai.models.Action
import com.cynex.core.managers.ActionManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AutomationTool @Inject constructor(private val actionManager: ActionManager) {
    suspend fun run(actions: List<Action>) = actionManager.run(actions)
}

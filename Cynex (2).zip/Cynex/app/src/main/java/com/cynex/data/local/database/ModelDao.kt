package com.cynex.data.local.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.cynex.data.local.entities.ModelEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ModelDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ModelEntity)

    @Query("SELECT * FROM models ORDER BY isActive DESC, name ASC")
    fun observeAll(): Flow<List<ModelEntity>>

    @Query("UPDATE models SET isActive = (path = :path)")
    suspend fun setActive(path: String)

    @Query("DELETE FROM models WHERE path = :path")
    suspend fun delete(path: String)
}

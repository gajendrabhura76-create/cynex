package com.cynex.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.cynex.ai.memory.SessionManager
import com.cynex.ai.models.AIResponse
import com.cynex.ai.models.ChatMessage
import com.cynex.ai.models.ModelConfig
import com.cynex.ai.engine.ModelRunner
import com.cynex.ai.prompts.AssistantPrompt
import com.cynex.core.managers.ActionManager
import com.cynex.core.managers.ModelManager
import com.cynex.core.utils.TimeUtils
import com.cynex.data.local.datastore.UserPreferences
import com.cynex.data.repository.ChatRepository
import com.cynex.data.repository.ModelRepository
import com.cynex.ui.components.ChatBubble
import com.cynex.ui.components.CynexSidebar
import com.cynex.ui.navigation.Routes
import com.cynex.ui.theme.CynexAccent
import com.cynex.ui.theme.CynexAccentAlt
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexSurface
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim
import com.cynex.voice.SpeechRecognizerManager
import com.cynex.voice.TextToSpeechManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.ExperimentalCoroutinesApi
import java.util.UUID
import javax.inject.Inject

@HiltViewModel
class ChatViewModel @Inject constructor(
    private val sessionManager: SessionManager,
    private val chatRepo: ChatRepository,
    private val modelRepo: ModelRepository,
    private val modelManager: ModelManager,
    private val runner: ModelRunner,
    private val actions: ActionManager,
    private val tts: TextToSpeechManager,
    val stt: SpeechRecognizerManager,
    private val prefs: UserPreferences
) : ViewModel() {

    @OptIn(ExperimentalCoroutinesApi::class)
    val messages: StateFlow<List<ChatMessage>> = sessionManager.id
        .flatMapLatest { id -> chatRepo.observe(id) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessions: StateFlow<List<String>> = chatRepo.sessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val streaming = MutableStateFlow(false)
    val streamBuffer = MutableStateFlow("")

    fun newChat() = sessionManager.startNew()

    fun selectSession(id: String) { /* hook for switching */ }

    fun send(text: String) {
        if (text.isBlank()) return
        val sessionId = sessionManager.id.value
        viewModelScope.launch {
            val user = ChatMessage(UUID.randomUUID().toString(), ChatMessage.Role.USER, text, TimeUtils.now())
            chatRepo.save(sessionId, user)

            streaming.value = true
            streamBuffer.value = ""
            val cfg = pickActiveConfig()
            runner.chatStream(text, cfg).collect { resp: AIResponse ->
                streamBuffer.value = resp.text
                if (resp.finished) {
                    streaming.value = false
                    val assistant = ChatMessage(
                        id = UUID.randomUUID().toString(),
                        role = ChatMessage.Role.ASSISTANT,
                        content = resp.text,
                        timestamp = TimeUtils.now()
                    )
                    chatRepo.save(sessionId, assistant)
                    streamBuffer.value = ""
                    if (resp.actions.isNotEmpty()) actions.run(resp.actions)
                    tts.speak(resp.text.take(280))
                }
            }
        }
    }

    private suspend fun pickActiveConfig(): ModelConfig {
        val firstModel = modelRepo.observe().first().firstOrNull()
        val cfg = firstModel ?: ModelConfig(
            name = "stub", path = "",
            contextSize = 2048, temperature = prefs.temperature.first(),
            maxTokens = prefs.maxTokens.first()
        )
        if (!modelManager.state.value.let { it is ModelManager.State.Loaded } && firstModel != null) {
            modelManager.load(firstModel)
        }
        return cfg
    }
}

@Composable
fun ChatScreen(
    navController: NavHostController,
    vm: ChatViewModel = hiltViewModel()
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val messages by vm.messages.collectAsState()
    val sessions by vm.sessions.collectAsState()
    val streaming by vm.streaming.collectAsState()
    val streamBuffer by vm.streamBuffer.collectAsState()
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }

    LaunchedEffect(messages.size, streamBuffer) {
        if (messages.isNotEmpty() || streamBuffer.isNotEmpty()) {
            listState.animateScrollToItem((messages.size + 1).coerceAtLeast(0))
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            CynexSidebar(
                sessions = sessions,
                onNewChat = { vm.newChat(); scope.launch { drawerState.close() } },
                onOpenSettings = {
                    scope.launch { drawerState.close() }
                    navController.navigate(Routes.SETTINGS)
                },
                onSessionSelected = { vm.selectSession(it) }
            )
        }
    ) {
        Scaffold(
            containerColor = CynexBg,
            topBar = {
                TopAppBar(
                    title = { Text("Cynex", color = CynexText) },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Outlined.Menu, contentDescription = "Menu", tint = CynexText)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = CynexBg)
                )
            }
        ) { padding ->
            Column(Modifier.padding(padding).fillMaxSize()) {
                if (messages.isEmpty() && streamBuffer.isEmpty()) {
                    EmptyState()
                } else {
                    LazyColumn(state = listState, modifier = Modifier.weight(1f)) {
                        items(messages) { ChatBubble(it) }
                        if (streaming) {
                            item {
                                ChatBubble(
                                    ChatMessage(
                                        id = "stream",
                                        role = ChatMessage.Role.ASSISTANT,
                                        content = streamBuffer,
                                        timestamp = TimeUtils.now(),
                                        streaming = true
                                    )
                                )
                            }
                        }
                    }
                }
                ChatInputBar(
                    value = input,
                    onValueChange = { input = it },
                    onSend = {
                        if (input.isNotBlank()) {
                            vm.send(input.trim()); input = ""
                        }
                    },
                    onMic = {
                        // Hook: start STT in a real implementation; here we just append a placeholder.
                        vm.stt.start()
                    }
                )
            }
        }
    }
}

@Composable
private fun EmptyState() {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(64.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(CynexAccent, CynexAccentAlt)))
        )
        Spacer(Modifier.height(16.dp))
        Text("Cynex", color = CynexText, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(AssistantPrompt.greeting, color = CynexTextDim,
             style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ChatInputBar(
    value: String,
    onValueChange: (String) -> Unit,
    onSend: () -> Unit,
    onMic: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
            .clip(RoundedCornerShape(28.dp))
            .background(CynexSurface)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onMic) {
            Icon(Icons.Outlined.Mic, contentDescription = "Voice", tint = CynexAccentAlt)
        }
        BasicTextField(
            value = value,
            onValueChange = onValueChange,
            singleLine = false,
            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
            textStyle = TextStyle(color = CynexText, fontSize = 16.sp),
            cursorBrush = SolidColor(CynexAccent),
            decorationBox = { inner ->
                if (value.isEmpty()) {
                    Text("Message Cynex…", color = CynexTextDim)
                }
                inner()
            }
        )
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Brush.linearGradient(listOf(CynexAccent, CynexAccentAlt)))
        ) {
            IconButton(onClick = onSend, modifier = Modifier.fillMaxSize()) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = CynexText)
            }
        }
    }
}

package com.cynex.ai.parser

import com.cynex.ai.models.Action
import com.cynex.core.utils.JsonUtils
import com.cynex.core.utils.Logger
import kotlinx.serialization.Serializable
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ActionExtractor @Inject constructor() {

    @Serializable
    private data class Wrapper(val actions: List<Action> = emptyList())

    private val jsonBlockRegex = Regex("```json\\s*(\\{[\\s\\S]*?\\})\\s*```", RegexOption.IGNORE_CASE)
    private val rawJsonRegex = Regex("\\{\\s*\"actions\"[\\s\\S]*?\\}")

    fun extract(text: String): List<Action> {
        val candidate = jsonBlockRegex.find(text)?.groupValues?.getOrNull(1)
            ?: rawJsonRegex.find(text)?.value
            ?: return emptyList()
        return try {
            JsonUtils.json.decodeFromString(Wrapper.serializer(), candidate).actions
        } catch (t: Throwable) {
            Logger.w("Failed to decode actions: $candidate", t)
            emptyList()
        }
    }
}

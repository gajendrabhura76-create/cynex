package com.cynex.automation.triggers
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VoiceTrigger @Inject constructor() {
    fun matches(text: String, phrase: String) = text.lowercase().contains(phrase.lowercase())
}

package com.cynex.data.local.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "automations")
data class AutomationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val triggerType: String,
    val triggerValue: String,
    val actionsJson: String,
    val enabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

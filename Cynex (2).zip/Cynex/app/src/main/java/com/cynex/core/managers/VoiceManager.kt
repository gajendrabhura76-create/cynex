package com.cynex.core.managers

import com.cynex.voice.SpeechRecognizerManager
import com.cynex.voice.TextToSpeechManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class VoiceManager @Inject constructor(
    val stt: SpeechRecognizerManager,
    val tts: TextToSpeechManager
)

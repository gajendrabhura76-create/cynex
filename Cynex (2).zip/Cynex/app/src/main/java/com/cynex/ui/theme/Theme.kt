package com.cynex.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val CynexColors = darkColorScheme(
    primary = CynexAccent,
    onPrimary = CynexText,
    secondary = CynexAccentAlt,
    onSecondary = CynexBg,
    background = CynexBg,
    onBackground = CynexText,
    surface = CynexSurface,
    onSurface = CynexText,
    surfaceVariant = CynexSurfaceAlt,
    onSurfaceVariant = CynexTextDim,
    outline = CynexBorder,
    error = CynexDanger
)

@Composable
fun CynexTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = CynexColors,
        typography = CynexTypography,
        shapes = CynexShapes,
        content = content
    )
}

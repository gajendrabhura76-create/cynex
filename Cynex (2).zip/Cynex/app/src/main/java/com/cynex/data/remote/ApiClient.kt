package com.cynex.data.remote

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ApiClient @Inject constructor()

package com.cynex.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.unit.dp
import com.cynex.ai.models.ChatMessage
import com.cynex.ui.theme.CynexAccent
import com.cynex.ui.theme.CynexAccentAlt
import com.cynex.ui.theme.CynexSurface
import com.cynex.ui.theme.CynexSurfaceAlt
import com.cynex.ui.theme.CynexText
import dev.jeziellago.compose.markdowntext.MarkdownText

@Composable
fun ChatBubble(message: ChatMessage) {
    val isUser = message.role == ChatMessage.Role.USER
    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 320.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(
                    if (isUser)
                        Brush.linearGradient(listOf(CynexAccent, CynexAccentAlt))
                    else
                        Brush.linearGradient(listOf(CynexSurface, CynexSurfaceAlt))
                )
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            if (isUser) {
                Text(message.content, color = CynexText, style = MaterialTheme.typography.bodyLarge)
            } else {
                if (message.streaming) {
                    StreamingText(
                        text = message.content,
                        isStreaming = true,
                        style = MaterialTheme.typography.bodyLarge,
                        color = CynexText
                    )
                } else {
                    MarkdownText(
                        markdown = message.content.ifBlank { "…" },
                        style = MaterialTheme.typography.bodyLarge.copy(color = CynexText)
                    )
                }
            }
        }
    }
}

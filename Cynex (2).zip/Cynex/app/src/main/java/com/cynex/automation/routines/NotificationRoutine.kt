package com.cynex.automation.routines

import com.cynex.ai.models.Action
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class NotificationRoutine @Inject constructor() {
    fun build(): List<Action> = listOf(Action(Action.Type.READ_NOTIFICATIONS))
}

package com.cynex.data.local.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.cynex.data.local.entities.AutomationEntity
import com.cynex.data.local.entities.ChatEntity
import com.cynex.data.local.entities.ModelEntity
import com.cynex.data.local.entities.SettingsEntity

@Database(
    entities = [ChatEntity::class, SettingsEntity::class, AutomationEntity::class, ModelEntity::class],
    version = 1,
    exportSchema = false
)
abstract class CynexDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao
    abstract fun settingsDao(): SettingsDao
    abstract fun automationDao(): AutomationDao
    abstract fun modelDao(): ModelDao
}

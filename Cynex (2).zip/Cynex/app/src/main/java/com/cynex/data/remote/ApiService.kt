package com.cynex.data.remote

/**
 * Cynex is fully on-device. This file is intentionally minimal.
 * Add remote endpoints here only if you later add optional cloud features.
 */
interface ApiService

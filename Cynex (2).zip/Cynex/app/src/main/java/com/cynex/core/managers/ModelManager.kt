package com.cynex.core.managers

import com.cynex.ai.engine.LlamaEngine
import com.cynex.ai.models.ModelConfig
import com.cynex.core.security.TokenManager
import com.cynex.core.utils.Logger
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ModelManager @Inject constructor(
    private val engine: LlamaEngine,
    private val tokenManager: TokenManager
) {
    private val _state = MutableStateFlow<State>(State.Idle)
    val state: StateFlow<State> = _state

    sealed class State {
        object Idle : State()
        data class Loading(val path: String) : State()
        data class Loaded(val config: ModelConfig) : State()
        data class Error(val msg: String) : State()
    }

    suspend fun load(config: ModelConfig): Boolean {
        _state.value = State.Loading(config.path)
        return try {
            val ok = engine.load(config)
            if (ok) {
                tokenManager.saveModelPath(config.path)
                _state.value = State.Loaded(config)
            } else _state.value = State.Error("Failed to load model")
            ok
        } catch (t: Throwable) {
            Logger.e("Model load failed", t)
            _state.value = State.Error(t.message ?: "unknown")
            false
        }
    }

    fun unload() {
        engine.unload()
        _state.value = State.Idle
    }
}

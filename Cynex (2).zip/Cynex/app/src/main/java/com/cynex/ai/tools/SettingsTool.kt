package com.cynex.ai.tools

import com.cynex.data.repository.SettingsRepository
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SettingsTool @Inject constructor(private val settings: SettingsRepository) {
    suspend fun set(key: String, value: String) = settings.set(key, value)
    suspend fun get(key: String): String? = settings.get(key)
}

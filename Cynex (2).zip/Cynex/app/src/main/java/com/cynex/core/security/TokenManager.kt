package com.cynex.core.security

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TokenManager @Inject constructor(private val securePrefs: SecurePrefs) {
    fun saveModelPath(path: String) = securePrefs.put("active_model_path", path)
    fun getModelPath(): String? = securePrefs.get("active_model_path")
    fun clearModelPath() = securePrefs.remove("active_model_path")
}

package com.cynex.data.remote

import kotlinx.serialization.Serializable

@Serializable
data class GenericResponse(val ok: Boolean, val message: String? = null)

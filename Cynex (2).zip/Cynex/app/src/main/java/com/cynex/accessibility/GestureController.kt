package com.cynex.accessibility

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class GestureController @Inject constructor() {
    fun buildSwipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 300L): GestureDescription {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        val stroke = GestureDescription.StrokeDescription(path, 0L, durationMs)
        return GestureDescription.Builder().addStroke(stroke).build()
    }

    fun buildTap(x: Float, y: Float): GestureDescription {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1f, y + 1f) }
        return GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, 50L)).build()
    }
}

package com.cynex.automation.scheduler

import android.content.Context
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class TaskScheduler @Inject constructor(@ApplicationContext private val context: Context) {
    fun scheduleOnce(tag: String) {
        val req = OneTimeWorkRequestBuilder<NoOpWorker>().addTag(tag).build()
        WorkManager.getInstance(context).enqueue(req)
    }

    class NoOpWorker(c: Context, p: WorkerParameters) : Worker(c, p) {
        override fun doWork(): Result = Result.success()
    }
}

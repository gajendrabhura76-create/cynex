package com.cynex.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.NavHostController
import com.cynex.data.local.datastore.UserPreferences
import com.cynex.ui.components.GradientButton
import com.cynex.ui.navigation.Routes
import com.cynex.ui.theme.CynexBg
import com.cynex.ui.theme.CynexText
import com.cynex.ui.theme.CynexTextDim
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class OnboardingViewModel @Inject constructor(private val prefs: UserPreferences) : ViewModel() {
    fun finish(then: () -> Unit) {
        viewModelScope.launch { prefs.setOnboardingDone(true); then() }
    }
}

private data class Page(val title: String, val body: String)

@Composable
fun OnboardingScreen(
    navController: NavHostController,
    vm: OnboardingViewModel = hiltViewModel()
) {
    val pages = listOf(
        Page("Welcome to Cynex", "A futuristic AI assistant that runs entirely on your device."),
        Page("Local AI Models", "Load any GGUF model, like DeepSeek R1 Distill 1.5B, and chat offline."),
        Page("Phone Control", "With your permission, Cynex can open apps, scroll, tap and read notifications.")
    )
    val pager = rememberPagerState(pageCount = { pages.size })
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().background(CynexBg).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(48.dp))
        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { i ->
            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(pages[i].title, color = CynexText, style = MaterialTheme.typography.displaySmall)
                Spacer(Modifier.height(16.dp))
                Text(pages[i].body, color = CynexTextDim,
                     style = MaterialTheme.typography.bodyLarge,
                     modifier = Modifier.padding(horizontal = 16.dp))
            }
        }
        GradientButton(
            text = if (pager.currentPage == pages.lastIndex) "Get Started" else "Next",
            onClick = {
                if (pager.currentPage < pages.lastIndex) {
                    scope.launch { pager.animateScrollToPage(pager.currentPage + 1) }
                } else {
                    vm.finish { navController.navigate(Routes.PERMISSIONS) { popUpTo(Routes.ONBOARDING) { inclusive = true } } }
                }
            },
            modifier = Modifier.padding(bottom = 24.dp)
        )
    }
}

package com.cynex.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import kotlin.math.*
import kotlin.random.Random

private data class Particle(
    val x0: Float, val y0: Float,
    val vx: Float, val vy: Float,
    val radius: Float,
    val color: Color,
    val speed: Float
)

@Composable
fun ParticleField(
    modifier: Modifier = Modifier,
    count: Int = 40,
    active: Boolean = true
) {
    val particles = remember {
        List(count) {
            Particle(
                x0 = Random.nextFloat(),
                y0 = Random.nextFloat(),
                vx = (Random.nextFloat() - 0.5f) * 0.0004f,
                vy = (Random.nextFloat() - 0.5f) * 0.0004f,
                radius = Random.nextFloat() * 2.5f + 0.5f,
                color = listOf(
                    Color(0xFF6C63FF), Color(0xFF00E5FF),
                    Color(0xFFB347FF), Color(0xFF00FF88)
                ).random().copy(alpha = Random.nextFloat() * 0.5f + 0.15f),
                speed = Random.nextFloat() * 0.6f + 0.4f
            )
        }
    }

    val time by rememberInfiniteTransition(label = "pt").animateFloat(
        initialValue = 0f, targetValue = 1000f,
        animationSpec = infiniteRepeatable(tween(1000000, easing = LinearEasing)),
        label = "t"
    )

    Canvas(modifier = modifier) {
        if (!active) return@Canvas
        val w = size.width; val h = size.height
        particles.forEach { p ->
            val t = time * p.speed
            val x = ((p.x0 + p.vx * t) % 1f + 1f) % 1f * w
            val y = ((p.y0 + p.vy * t) % 1f + 1f) % 1f * h
            drawCircle(p.color, p.radius, Offset(x, y))
        }
    }
}

// Cynex JNI bridge to llama.cpp.
//
// Build modes:
//   * If llama.cpp is present (CYNEX_HAVE_LLAMA defined), this file wires
//     real inference into the Kotlin layer.
//   * Otherwise, a stub implementation is compiled so the Kotlin code still
//     loads and the engine reports "not built" gracefully.
//
// To enable real inference:
//   cd app/src/main/cpp && git clone https://github.com/ggerganov/llama.cpp

#include <jni.h>
#include <string>
#include <vector>
#include <mutex>
#include <android/log.h>

#define LOG_TAG "cynex-llama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#ifdef CYNEX_HAVE_LLAMA
#include "llama.h"

namespace {
    struct CynexCtx {
        llama_model*   model = nullptr;
        llama_context* ctx   = nullptr;
        std::mutex     mu;
    };

    struct CynexSession {
        std::vector<llama_token> remaining;
        int   n_generated = 0;
        int   max_tokens  = 256;
        float temp        = 0.7f;
        float top_p       = 0.9f;
        int   top_k       = 40;
        float repeat_pen  = 1.1f;
    };
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeLoadModel(JNIEnv* env, jobject /*thiz*/,
        jstring jpath, jint ctxSize, jint nThreads, jint nGpuLayers) {
    const char* cpath = env->GetStringUTFChars(jpath, nullptr);
    std::string path(cpath);
    env->ReleaseStringUTFChars(jpath, cpath);

    llama_backend_init();

    auto* c = new CynexCtx();
    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = nGpuLayers;
    c->model = llama_load_model_from_file(path.c_str(), mparams);
    if (!c->model) { delete c; return 0L; }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx     = (uint32_t) ctxSize;
    cparams.n_threads = nThreads;
    cparams.n_threads_batch = nThreads;
    c->ctx = llama_new_context_with_model(c->model, cparams);
    if (!c->ctx) { llama_free_model(c->model); delete c; return 0L; }

    return reinterpret_cast<jlong>(c);
}

extern "C" JNIEXPORT void JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeFreeModel(JNIEnv*, jobject, jlong ctxPtr) {
    if (!ctxPtr) return;
    auto* c = reinterpret_cast<CynexCtx*>(ctxPtr);
    if (c->ctx)   llama_free(c->ctx);
    if (c->model) llama_free_model(c->model);
    delete c;
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeStartCompletion(JNIEnv* env, jobject,
        jlong ctxPtr, jstring jprompt, jint maxTokens,
        jfloat temp, jfloat topP, jint topK, jfloat repeatPen) {
    if (!ctxPtr) return 0L;
    auto* c = reinterpret_cast<CynexCtx*>(ctxPtr);
    const char* cpr = env->GetStringUTFChars(jprompt, nullptr);
    std::string prompt(cpr);
    env->ReleaseStringUTFChars(jprompt, cpr);

    auto* s = new CynexSession();
    s->max_tokens = maxTokens;
    s->temp       = temp;
    s->top_p      = topP;
    s->top_k      = topK;
    s->repeat_pen = repeatPen;

    std::vector<llama_token> tokens(prompt.size() + 8);
    int n = llama_tokenize(llama_get_model(c->ctx), prompt.c_str(), (int) prompt.size(),
                           tokens.data(), (int) tokens.size(), true, true);
    if (n < 0) { n = -n; tokens.resize(n); llama_tokenize(llama_get_model(c->ctx),
        prompt.c_str(), (int) prompt.size(), tokens.data(), n, true, true); }
    else tokens.resize(n);

    llama_batch batch = llama_batch_get_one(tokens.data(), n, 0, 0);
    {
        std::lock_guard<std::mutex> lk(c->mu);
        llama_kv_cache_clear(c->ctx);
        if (llama_decode(c->ctx, batch) != 0) { delete s; return 0L; }
    }
    return reinterpret_cast<jlong>(s);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeNextToken(JNIEnv* env, jobject,
        jlong ctxPtr, jlong sessPtr) {
    if (!ctxPtr || !sessPtr) return nullptr;
    auto* c = reinterpret_cast<CynexCtx*>(ctxPtr);
    auto* s = reinterpret_cast<CynexSession*>(sessPtr);

    if (s->n_generated >= s->max_tokens) return env->NewStringUTF("");

    std::lock_guard<std::mutex> lk(c->mu);
    const llama_model* model = llama_get_model(c->ctx);
    int   n_vocab = llama_n_vocab(model);
    auto* logits  = llama_get_logits_ith(c->ctx, -1);

    std::vector<llama_token_data> cands; cands.reserve(n_vocab);
    for (int id = 0; id < n_vocab; ++id) cands.push_back({id, logits[id], 0.0f});
    llama_token_data_array arr{cands.data(), cands.size(), false};

    llama_sample_top_k(c->ctx, &arr, s->top_k, 1);
    llama_sample_top_p(c->ctx, &arr, s->top_p, 1);
    llama_sample_temp (c->ctx, &arr, s->temp);
    llama_token tok = llama_sample_token(c->ctx, &arr);

    if (tok == llama_token_eos(model)) return env->NewStringUTF("");

    char buf[256] = {0};
    int n = llama_token_to_piece(model, tok, buf, sizeof(buf), 0, true);
    if (n < 0) return env->NewStringUTF("");

    llama_batch nb = llama_batch_get_one(&tok, 1, llama_get_kv_cache_token_count(c->ctx), 0);
    if (llama_decode(c->ctx, nb) != 0) return env->NewStringUTF("");
    s->n_generated++;
    return env->NewStringUTF(std::string(buf, n).c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeEndCompletion(JNIEnv*, jobject,
        jlong ctxPtr, jlong sessPtr) {
    (void) ctxPtr;
    if (!sessPtr) return;
    delete reinterpret_cast<CynexSession*>(sessPtr);
}

#else  // CYNEX_HAVE_LLAMA — stub mode

extern "C" JNIEXPORT jlong JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeLoadModel(JNIEnv*, jobject,
        jstring, jint, jint, jint) {
    LOGW("Cynex built without llama.cpp; running in stub mode");
    return 0L;
}
extern "C" JNIEXPORT void  JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeFreeModel(JNIEnv*, jobject, jlong) {}
extern "C" JNIEXPORT jlong JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeStartCompletion(JNIEnv*, jobject,
        jlong, jstring, jint, jfloat, jfloat, jint, jfloat) { return 0L; }
extern "C" JNIEXPORT jstring JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeNextToken(JNIEnv* env, jobject, jlong, jlong) {
    return env->NewStringUTF("");
}
extern "C" JNIEXPORT void JNICALL
Java_com_cynex_ai_engine_LlamaEngine_nativeEndCompletion(JNIEnv*, jobject, jlong, jlong) {}

#endif // CYNEX_HAVE_LLAMA

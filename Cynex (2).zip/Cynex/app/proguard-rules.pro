-keep class com.cynex.ai.engine.** { *; }
-keep class com.cynex.native.** { *; }
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn org.slf4j.**

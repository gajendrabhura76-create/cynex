# Get Your Cynex APK in 3 Steps

## Step 1 — Unzip the project

Unzip `Cynex.zip` anywhere on your computer (Desktop is fine).
You'll get a folder called `Cynex`.

---

## Step 2 — Run the setup script

**On Windows:**
- Open the `Cynex` folder
- Double-click `setup-windows.bat`
- Follow the prompts (it will open a browser to log in to GitHub)

**On Mac:**
- Open Terminal
- Drag the `Cynex` folder into Terminal (this types the path for you)
- Type `cd ` first so it looks like: `cd /Users/you/Desktop/Cynex`
- Press Enter, then type: `bash setup-mac-linux.sh`
- Press Enter and follow the prompts

**On Linux:**
- Open Terminal in the `Cynex` folder
- Run: `bash setup-mac-linux.sh`

---

## Step 3 — Wait ~10 minutes and download

The script will open your browser to GitHub Actions automatically.
When you see a green checkmark:

1. Click the run
2. Scroll to **Artifacts**
3. Click **cynex-debug-apk** → it downloads a zip
4. Unzip it → you have `app-debug.apk`

---

## Install on your Android phone

1. Send `app-debug.apk` to your phone (WhatsApp, Google Drive, USB cable)
2. Open it on your phone
3. Tap **Install** (if prompted, allow "Install from unknown sources" for your file manager)
4. Open **Cynex** and follow the setup wizard

---

## First time in the app

1. Grant permissions (mic, overlay, accessibility)
2. **Settings → Add / Manage Local Models → Add GGUF**
   → Download a model first: https://huggingface.co/bartowski/DeepSeek-R1-Distill-Qwen-1.5B-GGUF
   → Pick `DeepSeek-R1-Distill-Qwen-1.5B-Q4_K_M.gguf` (~1 GB)
3. Tap the model to activate it
4. Go to **Settings → Voice** → enable **Wake Word**
5. Say **"Hey Cynex"** — the orb lights up and it listens!

---

## Troubleshooting

| Problem | Fix |
|---|---|
| Script says "git not found" | Install git: https://git-scm.com |
| Script says "winget failed" | Download gh from https://cli.github.com |
| Build fails on GitHub | Check the Actions log — usually a Gradle version issue |
| Phone says "parse error" | Re-download the APK, make sure it fully downloaded |
| App crashes on open | Make sure your phone is Android 8.0 or newer |
